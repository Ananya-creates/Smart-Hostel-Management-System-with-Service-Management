<?php
require_once __DIR__ . '/helpers.php';
requireLogin('admin');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM students ORDER BY id");
    sendJson($stmt->fetchAll());
}

if ($method === 'POST') {
    $d = getJsonInput();
    $stmt = $pdo->prepare(
        "INSERT INTO students (id, name, email, password, phone, gender, course, year, room, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([
        $d['id'], $d['name'], $d['email'],
        $d['password'] ?? 'student123',
        $d['phone'] ?? '', $d['gender'] ?? '-',
        $d['course'] ?? '', $d['year'] ?? '',
        $d['room'] ?? '', $d['status'] ?? 'Active'
    ]);
    sendJson(['success' => true]);
}

if ($method === 'PUT') {
    $d = getJsonInput();
    $stmt = $pdo->prepare(
        "UPDATE students SET name=?, email=?, phone=?, course=?, year=?, status=?
         WHERE id=?"
    );
    $stmt->execute([
        $d['name'], $d['email'], $d['phone'] ?? '',
        $d['course'] ?? '', $d['year'] ?? '',
        $d['status'] ?? 'Active', $d['id']
    ]);
    sendJson(['success' => true]);
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    if (!$id) sendError('ID required');
    $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
    $stmt->execute([$id]);
    sendJson(['success' => true]);
}