<?php
require_once __DIR__ . '/helpers.php';
requireLogin('admin');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    sendJson($pdo->query("SELECT * FROM rooms ORDER BY number")->fetchAll());
}

if ($method === 'POST') {
    $d = getJsonInput();
    $stmt = $pdo->prepare(
        "INSERT INTO rooms (number, block, floor, type, capacity, occupied, status)
         VALUES (?, ?, ?, ?, ?, 0, 'Vacant')"
    );
    $stmt->execute([$d['number'], $d['block'], $d['floor'], $d['type'], $d['capacity']]);
    sendJson(['success' => true]);
}

if ($method === 'PUT') {
    $d = getJsonInput();
    $stmt = $pdo->prepare(
        "UPDATE rooms SET type=?, capacity=?, status=? WHERE number=?"
    );
    $stmt->execute([$d['type'], $d['capacity'], $d['status'], $d['number']]);
    sendJson(['success' => true]);
}

if ($method === 'DELETE') {
    $number = $_GET['number'] ?? '';
    if (!$number) sendError('Room number required');
    $stmt = $pdo->prepare("DELETE FROM rooms WHERE number = ?");
    $stmt->execute([$number]);
    sendJson(['success' => true]);
}