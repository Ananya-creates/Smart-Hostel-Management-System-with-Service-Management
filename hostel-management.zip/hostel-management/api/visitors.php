<?php
require_once __DIR__ . '/helpers.php';
$user = requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if ($user['role'] === 'admin') {
        $stmt = $pdo->query("
            SELECT v.*, s.name AS studentName 
            FROM visitors v 
            JOIN students s ON s.id = v.student_id 
            ORDER BY v.date DESC, v.time DESC
        ");
    } else {
        $stmt = $pdo->prepare("
            SELECT v.*, s.name AS studentName 
            FROM visitors v 
            JOIN students s ON s.id = v.student_id 
            WHERE v.student_id = ? 
            ORDER BY v.date DESC
        ");
        $stmt->execute([$user['studentId']]);
    }
    sendJson($stmt->fetchAll());
}

if ($method === 'POST') {
    $d = getJsonInput();
    $id = 'VIS' . str_pad(rand(100, 999), 3, '0', STR_PAD_LEFT);
    $stmt = $pdo->prepare("
        INSERT INTO visitors (id, student_id, visitor, relation, date, time, status)
        VALUES (?, ?, ?, ?, ?, ?, 'Inside Hostel')
    ");
    $stmt->execute([
        $id, $d['studentId'], $d['visitor'],
        $d['relation'], $d['date'], $d['time']
    ]);
    sendJson(['success' => true, 'id' => $id]);
}

if ($method === 'PUT') {
    $d = getJsonInput();
    $stmt = $pdo->prepare("UPDATE visitors SET status=? WHERE id=?");
    $stmt->execute([$d['status'], $d['id']]);
    sendJson(['success' => true]);
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    $stmt = $pdo->prepare("DELETE FROM visitors WHERE id = ?");
    $stmt->execute([$id]);
    sendJson(['success' => true]);
}