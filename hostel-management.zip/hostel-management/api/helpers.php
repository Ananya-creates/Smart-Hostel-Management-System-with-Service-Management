<?php
// ============================================
// Common helper functions (SIRF definitions)
// ============================================

session_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/db.php';

// ---------- JSON input read ----------
function getJsonInput() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// ---------- Success response ----------
function sendJson($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

// ---------- Error response ----------
function sendError($msg, $code = 400) {
    http_response_code($code);
    echo json_encode(['error' => $msg]);
    exit;
}

// ---------- Login check ----------
function requireLogin($role = null) {
    if (!isset($_SESSION['user'])) {
        sendError('Not authenticated', 401);
    }
    if ($role && $_SESSION['user']['role'] !== $role) {
        sendError('Forbidden', 403);
    }
    return $_SESSION['user'];
}