<?php
require_once __DIR__ . '/helpers.php';
$user = requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if ($user['role'] === 'admin') {
        $stmt = $pdo->query("
            SELECT c.*, s.name AS studentName 
            FROM complaints c 
            JOIN students s ON s.id = c.student_id 
            ORDER BY c.date DESC
        ");
    } else {
        $stmt = $pdo->prepare("
            SELECT c.*, s.name AS studentName 
            FROM complaints c 
            JOIN students s ON s.id = c.student_id 
            WHERE c.student_id = ? 
            ORDER BY c.date DESC
        ");
        $stmt->execute([$user['studentId']]);
    }
    sendJson($stmt->fetchAll());
}

if ($method === 'POST') {
    $d = getJsonInput();
    $stmt = $pdo->prepare("
        INSERT INTO complaints (id, student_id, room, title, category, priority, status, description, date)
        VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?, CURDATE())
    ");
    $id = 'CMP' . str_pad(rand(100, 999), 3, '0', STR_PAD_LEFT);
    $stmt->execute([
        $id, $d['studentId'], $d['room'] ?? '',
        $d['title'], $d['category'], $d['priority'],
        $d['description'] ?? ''
    ]);
    sendJson(['success' => true, 'id' => $id]);
}

if ($method === 'PUT') {
    $d = getJsonInput();
    $stmt = $pdo->prepare("UPDATE complaints SET priority=?, status=? WHERE id=?");
    $stmt->execute([$d['priority'], $d['status'], $d['id']]);
    sendJson(['success' => true]);
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    $stmt = $pdo->prepare("DELETE FROM complaints WHERE id = ?");
    $stmt->execute([$id]);
    sendJson(['success' => true]);
}