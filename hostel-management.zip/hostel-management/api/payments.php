<?php
require_once __DIR__ . '/helpers.php';
$user = requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if ($user['role'] === 'admin') {
        $stmt = $pdo->query("
            SELECT p.*, s.name AS studentName 
            FROM payments p 
            JOIN students s ON s.id = p.student_id 
            ORDER BY p.date DESC
        ");
    } else {
        $stmt = $pdo->prepare("
            SELECT p.*, s.name AS studentName 
            FROM payments p 
            JOIN students s ON s.id = p.student_id 
            WHERE p.student_id = ? 
            ORDER BY p.date DESC
        ");
        $stmt->execute([$user['studentId']]);
    }
    sendJson($stmt->fetchAll());
}

if ($method === 'POST') {
    $d = getJsonInput();
    $id = 'TXN' . rand(1500, 9999);
    $stmt = $pdo->prepare("
        INSERT INTO payments (id, student_id, amount, method, date, status, year)
        VALUES (?, ?, ?, ?, ?, ?, '2026-2027')
    ");
    $stmt->execute([
        $id, $d['studentId'], $d['amount'],
        $d['method'], $d['date'], $d['status']
    ]);
    sendJson(['success' => true, 'id' => $id]);
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    $stmt = $pdo->prepare("DELETE FROM payments WHERE id = ?");
    $stmt->execute([$id]);
    sendJson(['success' => true]);
}