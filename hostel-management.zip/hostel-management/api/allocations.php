<?php
require_once __DIR__ . '/helpers.php';
requireLogin('admin');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->query("
        SELECT a.*, s.name AS studentName 
        FROM allocations a 
        JOIN students s ON s.id = a.student_id 
        ORDER BY a.date DESC
    ");
    sendJson($stmt->fetchAll());
}

if ($method === 'POST') {
    $d = getJsonInput();
    $id = 'AL' . str_pad(rand(100, 999), 3, '0', STR_PAD_LEFT);

    // Insert allocation
    $stmt = $pdo->prepare("
        INSERT INTO allocations (id, student_id, room, bed, date)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$id, $d['studentId'], $d['room'], $d['bed'], $d['date']]);

    // Update student's room
    $stmt = $pdo->prepare("UPDATE students SET room=?, status='Active' WHERE id=?");
    $stmt->execute([$d['room'], $d['studentId']]);

    // Update room occupancy
    $stmt = $pdo->prepare("UPDATE rooms SET occupied = occupied + 1 WHERE number = ?");
    $stmt->execute([$d['room']]);

    sendJson(['success' => true, 'id' => $id]);
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    $stmt = $pdo->prepare("SELECT room, student_id FROM allocations WHERE id=?");
    $stmt->execute([$id]);
    $a = $stmt->fetch();

    if ($a) {
        $stmt = $pdo->prepare("DELETE FROM allocations WHERE id=?");
        $stmt->execute([$id]);

        $stmt = $pdo->prepare("UPDATE rooms SET occupied = GREATEST(0, occupied - 1) WHERE number=?");
        $stmt->execute([$a['room']]);
    }
    sendJson(['success' => true]);
}