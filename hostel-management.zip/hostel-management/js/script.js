/* ============================================
   Hostel Management System — Shared Script
   Vanilla JS. Uses localStorage for data.
   ============================================ */

// ---------- SEED DATA ----------
const SEED = {
    admin: { email: 'admin@hostel.com', password: 'admin123', name: 'System Administrator' },

    students: [
        { id: 'ST001', name: 'Riya Sharma',   email: 'riya@hostel.com',    password: 'student123', phone: '9876543210', gender: 'Female', course: 'B.Tech CSE',   year: '3rd Year', room: 'A-102', status: 'Active' },
        { id: 'ST014', name: 'Arjun Kumar',   email: 'arjun@hostel.com',   password: 'student123', phone: '9876501112', gender: 'Female', course: 'B.Tech IT',    year: '3rd Year', room: 'A-102', status: 'Active' },
        { id: 'ST022', name: 'Neha Patil',    email: 'neha@hostel.com',    password: 'student123', phone: '9812345678', gender: 'Female', course: 'B.Sc Physics', year: '2nd Year', room: 'A-102', status: 'Active' },
        { id: 'ST031', name: 'Aditya Rao',    email: 'aditya@hostel.com',  password: 'student123', phone: '9900112233', gender: 'Male',   course: 'B.Tech ECE',   year: '1st Year', room: 'B-201', status: 'Active' },
        { id: 'ST045', name: 'Sneha Iyer',    email: 'sneha@hostel.com',   password: 'student123', phone: '9911223344', gender: 'Female', course: 'BBA',          year: '2nd Year', room: 'C-105', status: 'Active' },
        { id: 'ST052', name: 'Karan Verma',   email: 'karan@hostel.com',   password: 'student123', phone: '9922334455', gender: 'Male',   course: 'B.Tech Mech',  year: '4th Year', room: 'B-208', status: 'Active' },
        { id: 'ST067', name: 'Priya Nair',    email: 'priyanair@hostel.com', password: 'student123', phone: '9933445566', gender: 'Female', course: 'B.Com',      year: '1st Year', room: '',      status: 'Pending' },
        { id: 'ST078', name: 'Rohan Desai',   email: 'rohan@hostel.com',   password: 'student123', phone: '9944556677', gender: 'Male',   course: 'B.Tech CSE',   year: '2nd Year', room: 'C-110', status: 'Active' }
    ],

    rooms: [
        { number: 'A-101', block: 'A', floor: '1st Floor', type: 'Double Sharing', capacity: 2, occupied: 2, status: 'Full' },
        { number: 'A-102', block: 'A', floor: '1st Floor', type: 'Triple Sharing', capacity: 3, occupied: 3, status: 'Full' },
        { number: 'A-103', block: 'A', floor: '1st Floor', type: 'Double Sharing', capacity: 2, occupied: 1, status: 'Available' },
        { number: 'B-201', block: 'B', floor: '2nd Floor', type: 'Triple Sharing', capacity: 3, occupied: 2, status: 'Available' },
        { number: 'B-208', block: 'B', floor: '2nd Floor', type: 'Single',         capacity: 1, occupied: 1, status: 'Full' },
        { number: 'C-105', block: 'C', floor: '1st Floor', type: 'Double Sharing', capacity: 2, occupied: 1, status: 'Available' },
        { number: 'C-110', block: 'C', floor: '1st Floor', type: 'Triple Sharing', capacity: 3, occupied: 1, status: 'Available' },
        { number: 'C-115', block: 'C', floor: '1st Floor', type: 'Double Sharing', capacity: 2, occupied: 0, status: 'Vacant' }
    ],

    allocations: [
        { id: 'AL001', studentId: 'ST001', studentName: 'Riya Sharma',  room: 'A-102', bed: 'B2', date: '2026-07-01' },
        { id: 'AL002', studentId: 'ST014', studentName: 'Arjun Kumar',  room: 'A-102', bed: 'B1', date: '2026-07-01' },
        { id: 'AL003', studentId: 'ST022', studentName: 'Neha Patil',   room: 'A-102', bed: 'B3', date: '2026-07-02' },
        { id: 'AL004', studentId: 'ST031', studentName: 'Aditya Rao',   room: 'B-201', bed: 'B1', date: '2026-07-05' },
        { id: 'AL005', studentId: 'ST045', studentName: 'Sneha Iyer',   room: 'C-105', bed: 'B1', date: '2026-07-08' },
        { id: 'AL006', studentId: 'ST052', studentName: 'Karan Verma',  room: 'B-208', bed: 'B1', date: '2026-06-28' },
        { id: 'AL007', studentId: 'ST078', studentName: 'Rohan Desai',  room: 'C-110', bed: 'B2', date: '2026-07-10' }
    ],

    complaints: [
        { id: 'CMP001', studentId: 'ST001', studentName: 'Riya Sharma', room: 'A-102', title: 'Ceiling Fan Not Working', category: 'Electrical', priority: 'High',   status: 'In Progress', date: '2026-08-28', desc: 'The ceiling fan in room A-102 stopped rotating since yesterday.' },
        { id: 'CMP002', studentId: 'ST001', studentName: 'Riya Sharma', room: 'A-102', title: 'Leaking tap in bathroom',  category: 'Plumbing',   priority: 'Medium', status: 'Resolved',    date: '2026-08-15', desc: 'Wash basin tap leaks water continuously.' },
        { id: 'CMP003', studentId: 'ST031', studentName: 'Aditya Rao',  room: 'B-201', title: 'Wi-Fi connection issue',  category: 'Internet',   priority: 'High',   status: 'Pending',     date: '2026-09-01', desc: 'Internet is very slow in B-201 in the evening.' },
        { id: 'CMP004', studentId: 'ST045', studentName: 'Sneha Iyer',  room: 'C-105', title: 'Dirty common washroom',    category: 'Cleaning',   priority: 'Low',    status: 'Resolved',    date: '2026-08-20', desc: 'Common washroom on ground floor is not cleaned regularly.' },
        { id: 'CMP005', studentId: 'ST052', studentName: 'Karan Verma', room: 'B-208', title: 'Broken window latch',      category: 'Maintenance', priority: 'Medium', status: 'In Progress', date: '2026-08-30', desc: 'Window latch is broken and does not close properly.' }
    ],

    visitors: [
        { id: 'VIS001', studentId: 'ST001', studentName: 'Riya Sharma', visitor: 'Rahul Kumar',   relation: 'Brother', date: '2026-09-03', time: '14:15', status: 'Inside Hostel' },
        { id: 'VIS002', studentId: 'ST001', studentName: 'Riya Sharma', visitor: 'Meena Sharma',  relation: 'Mother',  date: '2026-08-20', time: '11:00', status: 'Checked Out' },
        { id: 'VIS003', studentId: 'ST031', studentName: 'Aditya Rao',  visitor: 'Sunita Rao',    relation: 'Mother',  date: '2026-09-01', time: '16:30', status: 'Checked Out' },
        { id: 'VIS004', studentId: 'ST045', studentName: 'Sneha Iyer',  visitor: 'Vikram Iyer',   relation: 'Father',  date: '2026-09-02', time: '10:45', status: 'Checked Out' },
        { id: 'VIS005', studentId: 'ST052', studentName: 'Karan Verma', visitor: 'Aman Verma',    relation: 'Brother', date: '2026-09-03', time: '09:20', status: 'Inside Hostel' }
    ],

    payments: [
        { id: 'TXN1001', studentId: 'ST001', studentName: 'Riya Sharma', amount: 30000, method: 'UPI',        date: '2026-07-01', status: 'Paid', year: '2026-2027' },
        { id: 'TXN0987', studentId: 'ST001', studentName: 'Riya Sharma', amount: 20000, method: 'Card',       date: '2026-06-10', status: 'Paid', year: '2026-2027' },
        { id: 'TXN0854', studentId: 'ST001', studentName: 'Riya Sharma', amount: 10000, method: 'Net Banking',date: '2026-05-20', status: 'Paid', year: '2026-2027' },
        { id: 'TXN1102', studentId: 'ST014', studentName: 'Arjun Kumar', amount: 60000, method: 'UPI',        date: '2026-07-04', status: 'Paid', year: '2026-2027' },
        { id: 'TXN1150', studentId: 'ST022', studentName: 'Neha Patil',  amount: 40000, method: 'Card',       date: '2026-07-06', status: 'Partial', year: '2026-2027' },
        { id: 'TXN1201', studentId: 'ST031', studentName: 'Aditya Rao',  amount: 60000, method: 'UPI',        date: '2026-07-08', status: 'Paid', year: '2026-2027' },
        { id: 'TXN1245', studentId: 'ST045', studentName: 'Sneha Iyer',  amount: 30000, method: 'Cash',       date: '2026-07-12', status: 'Partial', year: '2026-2027' },
        { id: 'TXN1300', studentId: 'ST052', studentName: 'Karan Verma', amount: 60000, method: 'Net Banking',date: '2026-07-15', status: 'Paid', year: '2026-2027' }
    ],

    notifications: [
        { id: 'N1', title: 'Fee payment reminder',  msg: 'Your next semester fee is due on 15 Nov 2026. Please pay on time to avoid late charges.', time: '2 days ago',  read: false },
        { id: 'N2', title: 'Complaint update',      msg: 'Your complaint "Ceiling Fan Not Working" has been marked as In Progress by warden.',    time: '3 days ago',  read: false },
        { id: 'N3', title: 'Visitor entry',         msg: 'Your visitor Rahul Kumar has entered the hostel premises.',                                time: '5 days ago',  read: true },
        { id: 'N4', title: 'Hostel notice',         msg: 'Diwali holiday: hostel will follow a modified visitor schedule from 05 Nov to 10 Nov.',     time: '1 week ago',  read: true },
        { id: 'N5', title: 'Room inspection',       msg: 'Monthly room inspection is scheduled for 20 Sep 2026 between 10 AM to 1 PM.',              time: '1 week ago',  read: true }
    ]
};

const TOTAL_FEE = 60000;

// ---------- STORAGE HELPERS ----------
function initStore() {
    if (!localStorage.getItem('hms_init')) {
        localStorage.setItem('hms_students',      JSON.stringify(SEED.students));
        localStorage.setItem('hms_rooms',         JSON.stringify(SEED.rooms));
        localStorage.setItem('hms_allocations',   JSON.stringify(SEED.allocations));
        localStorage.setItem('hms_complaints',    JSON.stringify(SEED.complaints));
        localStorage.setItem('hms_visitors',      JSON.stringify(SEED.visitors));
        localStorage.setItem('hms_payments',      JSON.stringify(SEED.payments));
        localStorage.setItem('hms_notifications', JSON.stringify(SEED.notifications));
        localStorage.setItem('hms_init', '1');
    }
}
function db(key) { return JSON.parse(localStorage.getItem('hms_' + key) || '[]'); }
function save(key, data) { localStorage.setItem('hms_' + key, JSON.stringify(data)); }

// ---------- AUTH ----------
function getSession() { return JSON.parse(sessionStorage.getItem('hms_session') || 'null'); }
function setSession(s) { sessionStorage.setItem('hms_session', JSON.stringify(s)); }
function logout() { sessionStorage.removeItem('hms_session'); window.location.href = 'login.html'; }

function requireAuth(role) {
    initStore();
    const s = getSession();
    if (!s) { window.location.href = 'login.html'; return null; }
    if (role && s.role !== role) {
        window.location.href = s.role === 'admin' ? 'dashboard.html' : 'student-dashboard.html';
        return null;
    }
    return s;
}

// ---------- UI HELPERS ----------
function toast(msg, type) {
    let t = document.getElementById('hms-toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'hms-toast';
        t.className = 'toast';
        document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = 'toast ' + (type || '') + ' show';
    setTimeout(() => t.className = 'toast ' + (type || ''), 2400);
}

function badge(status) {
    const map = {
        'Active': 'success', 'Paid': 'success', 'Resolved': 'success', 'Available': 'success', 'Checked Out': 'neutral',
        'Pending': 'warning', 'Partial': 'warning', 'In Progress': 'warning', 'Inside Hostel': 'info',
        'Full': 'danger', 'Vacant': 'info', 'Blocked': 'danger',
        'High': 'danger', 'Medium': 'warning', 'Low': 'info'
    };
    return `<span class="badge badge-${map[status] || 'neutral'}">${status}</span>`;
}

function initials(name) {
    return name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();
}

function fmtDate(d) {
    if (!d) return '-';
    const dt = new Date(d);
    return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtMoney(n) { return '\u20B9' + Number(n).toLocaleString('en-IN'); }

// ---------- SIDEBAR ----------
function toggleSidebar() {
    const sb = document.querySelector('.sidebar');
    const ov = document.querySelector('.sidebar-overlay');
    if (sb) sb.classList.toggle('open');
    if (ov) ov.classList.toggle('show');
}

function renderLayout(role, activeKey, pageTitle, pageSub) {
    const s = getSession();
    const uName = s ? s.name : (role === 'admin' ? 'Administrator' : 'Student');
    const uRole = role === 'admin' ? 'ADMIN' : 'STUDENT';

    const adminMenu = [
        { k: 'dashboard',   label: 'Dashboard',       ico: '\u25A6', href: 'dashboard.html' },
        { k: 'students',    label: 'Students',        ico: '\u2632', href: 'students.html' },
        { k: 'rooms',       label: 'Rooms',           ico: '\u25A3', href: 'rooms.html' },
        { k: 'allocation',  label: 'Room Allocation', ico: '\u2691', href: 'room-allocation.html' },
        { k: 'complaints',  label: 'Complaints',      ico: '\u26A0', href: 'complaints.html' },
        { k: 'visitors',    label: 'Visitors',        ico: '\u263A', href: 'visitors.html' },
        { k: 'payments',    label: 'Payments',        ico: '\u20B9', href: 'payments.html' }
    ];
    const studentMenu = [
        { k: 'dashboard',    label: 'Dashboard',     ico: '\u25A6', href: 'student-dashboard.html' },
        { k: 'profile',      label: 'My Profile',    ico: '\u263A', href: 'student-profile.html' },
        { k: 'room',         label: 'My Room',       ico: '\u25A3', href: 'my-room.html' },
        { k: 'complaints',   label: 'My Complaints', ico: '\u26A0', href: 'my-complaints.html' },
        { k: 'visitors',     label: 'My Visitors',   ico: '\u2691', href: 'my-visitors.html' },
        { k: 'payments',     label: 'My Payments',   ico: '\u20B9', href: 'my-payments.html' },
        { k: 'notifications',label: 'Notifications', ico: '\u2709', href: 'notifications.html' }
    ];
    const menu = role === 'admin' ? adminMenu : studentMenu;

    const menuHtml = menu.map(m =>
        `<a href="${m.href}" class="nav-item ${m.k === activeKey ? 'active' : ''}" data-testid="nav-${m.k}">
            <span class="ico">${m.ico}</span>${m.label}
        </a>`).join('');

    document.body.innerHTML = `
        <div class="sidebar-overlay" onclick="toggleSidebar()"></div>
        <div class="layout">
            <aside class="sidebar">
                <div class="brand">
                    <div class="brand-logo">H</div>
                    <div>Hostel MS<span class="role-tag">${uRole}</span></div>
                </div>
                <div class="menu-label">Menu</div>
                ${menuHtml}
                <div class="logout-block">
                    <a href="#" class="nav-item" onclick="logout();return false;" data-testid="btn-logout">
                        <span class="ico">\u2B8C</span>Logout
                    </a>
                </div>
            </aside>
            <div>
                <header class="topbar">
                    <div style="display:flex;align-items:center;gap:12px;">
                        <button class="hamburger" onclick="toggleSidebar()" data-testid="btn-hamburger">\u2630</button>
                        <div class="page-title">${pageTitle}<small>${pageSub || ''}</small></div>
                    </div>
                    <div class="user-chip">
                        <span class="avatar">${initials(uName)}</span>
                        <span class="u-name">${uName}</span>
                    </div>
                </header>
                <main class="main" id="page-main"></main>
            </div>
        </div>`;
}

// ---------- MODAL ----------
function openModal(title, bodyHtml, onSubmit, submitLabel) {
    let m = document.getElementById('hms-modal');
    if (!m) {
        m = document.createElement('div');
        m.id = 'hms-modal';
        m.className = 'modal-backdrop';
        document.body.appendChild(m);
    }
    m.innerHTML = `
        <div class="modal">
            <div class="modal-head">
                <h3>${title}</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <form id="hms-modal-form" method="POST">
                <div class="modal-body">${bodyHtml}</div>
                <div class="modal-foot">
                    <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-testid="modal-submit">${submitLabel || 'Save'}</button>
                </div>
            </form>
        </div>`;
    m.classList.add('show');
    document.getElementById('hms-modal-form').addEventListener('submit', e => {
        e.preventDefault();
        const data = {};
        new FormData(e.target).forEach((v, k) => data[k] = v);
        onSubmit(data);
    });
}
function closeModal() {
    const m = document.getElementById('hms-modal');
    if (m) m.classList.remove('show');
}

// ---------- FEE / PAYMENT HELPERS ----------
function feeSummary(studentId) {
    const paid = db('payments').filter(p => p.studentId === studentId && p.status === 'Paid')
                  .reduce((s, p) => s + Number(p.amount), 0);
    return { total: TOTAL_FEE, paid, pending: TOTAL_FEE - paid, pct: Math.min(100, Math.round(paid / TOTAL_FEE * 100)) };
}

// ---------- PASSWORD TOGGLE ----------
function togglePassword(inputId, btn) {
    const inp = document.getElementById(inputId);
    if (inp.type === 'password') { inp.type = 'text'; btn.textContent = 'HIDE'; }
    else { inp.type = 'password'; btn.textContent = 'SHOW'; }
}

// Init on load
initStore();
