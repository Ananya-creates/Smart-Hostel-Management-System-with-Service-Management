/* ================= MOBILE MENU ================= */

function toggleMenu() {
    const navMenu = document.getElementById("navMenu");

    if (navMenu) {
        navMenu.classList.toggle("show");
    }
}


/* ================= PASSWORD TOGGLE ================= */

function togglePassword(inputId, button) {
    const passwordInput = document.getElementById(inputId);

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        button.innerHTML = "🙈";
    } else {
        passwordInput.type = "password";
        button.innerHTML = "👁";
    }
}
/* ================= LOGIN VALIDATION ================= */

function validateLogin() {

    const role = document.getElementById("loginRole");
    const email = document.getElementById("loginEmail");
    const password = document.getElementById("loginPassword");

    const roleError = document.getElementById("roleError");
    const emailError = document.getElementById("emailError");
    const passwordError = document.getElementById("passwordError");

    roleError.innerHTML = "";
    emailError.innerHTML = "";
    passwordError.innerHTML = "";

    let valid = true;


    /* ROLE VALIDATION */

    if (role.value === "") {

        roleError.innerHTML = "Please select your role.";
        valid = false;

    }


    /* EMAIL VALIDATION */

    if (email.value.trim() === "") {

        emailError.innerHTML = "Email is required.";
        valid = false;

    }
    else if (!validateEmail(email.value.trim())) {

        emailError.innerHTML = "Please enter a valid email address.";
        valid = false;

    }


    /* PASSWORD VALIDATION */

    if (password.value === "") {

        passwordError.innerHTML = "Password is required.";
        valid = false;

    }
    else if (password.value.length < 6) {

        passwordError.innerHTML =
            "Password must contain at least 6 characters.";

        valid = false;

    }


    /* LOGIN */

    if (!valid) {

        return false;

    }


    alert("Login successful!");


    if (role.value === "student") {

        window.location.href = "student-dashboard.html";

    }
    else if (role.value === "admin") {

        window.location.href = "dashboard.html";

    }


    return false;
}


/* ================= EMAIL VALIDATION ================= */

function validateEmail(email) {

    const pattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return pattern.test(email);

}




/* ================= REGISTRATION VALIDATION ================= */

function validateRegistration() {

    const name =
        document.getElementById("fullName").value.trim();

    const email =
        document.getElementById("registerEmail").value.trim();

    const phone =
        document.getElementById("phone").value.trim();

    const gender =
        document.getElementById("gender").value;

    const course =
        document.getElementById("course").value.trim();

    const password =
        document.getElementById("registerPassword").value;

    const confirmPassword =
        document.getElementById("confirmPassword").value;

    const terms =
        document.getElementById("terms").checked;


    document.getElementById("nameError").innerHTML = "";
    document.getElementById("registerEmailError").innerHTML = "";
    document.getElementById("phoneError").innerHTML = "";
    document.getElementById("genderError").innerHTML = "";
    document.getElementById("courseError").innerHTML = "";
    document.getElementById("registerPasswordError").innerHTML = "";
    document.getElementById("confirmPasswordError").innerHTML = "";
    document.getElementById("termsError").innerHTML = "";


    let valid = true;


    if (name === "") {

        document.getElementById("nameError").innerHTML =
            "Full name is required.";

        valid = false;
    }


    if (email === "") {

        document.getElementById("registerEmailError").innerHTML =
            "Email is required.";

        valid = false;

    } else if (!validateEmail(email)) {

        document.getElementById("registerEmailError").innerHTML =
            "Enter a valid email address.";

        valid = false;
    }


    if (phone === "") {

        document.getElementById("phoneError").innerHTML =
            "Phone number is required.";

        valid = false;

    } else if (!/^[0-9]{10}$/.test(phone)) {

        document.getElementById("phoneError").innerHTML =
            "Enter a valid 10-digit phone number.";

        valid = false;
    }


    if (gender === "") {

        document.getElementById("genderError").innerHTML =
            "Please select your gender.";

        valid = false;
    }


    if (course === "") {

        document.getElementById("courseError").innerHTML =
            "Course is required.";

        valid = false;
    }


    if (password === "") {

        document.getElementById("registerPasswordError").innerHTML =
            "Password is required.";

        valid = false;

    } else if (password.length < 6) {

        document.getElementById("registerPasswordError").innerHTML =
            "Password must contain at least 6 characters.";

        valid = false;
    }


    if (confirmPassword === "") {

        document.getElementById("confirmPasswordError").innerHTML =
            "Please confirm your password.";

        valid = false;

    } else if (password !== confirmPassword) {

        document.getElementById("confirmPasswordError").innerHTML =
            "Passwords do not match.";

        valid = false;
    }


    if (!terms) {

        document.getElementById("termsError").innerHTML =
            "Please accept the terms and conditions.";

        valid = false;
    }


    if (valid) {

        alert("Registration successful!");

        window.location.href = "login.html";
    }


    return false;
}


/* ================= DASHBOARD SIDEBAR ================= */

function toggleSidebar() {

    const sidebar =
        document.getElementById("sidebar");

    if (sidebar) {
        sidebar.classList.toggle("show");
    }
}


/* ================= DASHBOARD SEARCH ================= */

const dashboardSearch =
    document.getElementById("dashboardSearch");

if (dashboardSearch) {

    dashboardSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const activities =
            document.querySelectorAll(".dashboard-activity");

        activities.forEach(function (activity) {

            const text =
                activity.innerText.toLowerCase();

            if (text.includes(searchText)) {
                activity.style.display = "flex";
            } else {
                activity.style.display = "none";
            }
        });
    });
}


/* ================= STUDENT FORM ================= */

function openStudentForm() {

    const formPanel =
        document.getElementById("studentFormPanel");

    if (formPanel) {

        formPanel.classList.add("show");

        formPanel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


function closeStudentForm() {

    const formPanel =
        document.getElementById("studentFormPanel");

    if (formPanel) {
        formPanel.classList.remove("show");
    }
}


/* ================= STUDENT VALIDATION ================= */

function validateStudentForm() {

    const name =
        document.getElementById("studentName").value.trim();

    const email =
        document.getElementById("studentEmail").value.trim();

    const phone =
        document.getElementById("studentPhone").value.trim();

    const gender =
        document.getElementById("studentGender").value;

    const dob =
        document.getElementById("studentDob").value;

    const course =
        document.getElementById("studentCourse").value;

    const address =
        document.getElementById("studentAddress").value.trim();


    document.getElementById("studentNameError").innerHTML = "";
    document.getElementById("studentEmailError").innerHTML = "";
    document.getElementById("studentPhoneError").innerHTML = "";
    document.getElementById("studentGenderError").innerHTML = "";
    document.getElementById("studentDobError").innerHTML = "";
    document.getElementById("studentCourseError").innerHTML = "";
    document.getElementById("studentAddressError").innerHTML = "";


    let valid = true;


    if (name === "") {

        document.getElementById("studentNameError").innerHTML =
            "Student name is required.";

        valid = false;
    }


    if (email === "") {

        document.getElementById("studentEmailError").innerHTML =
            "Email address is required.";

        valid = false;

    } else if (!validateEmail(email)) {

        document.getElementById("studentEmailError").innerHTML =
            "Enter a valid email address.";

        valid = false;
    }


    if (phone === "") {

        document.getElementById("studentPhoneError").innerHTML =
            "Phone number is required.";

        valid = false;

    } else if (!/^[0-9]{10}$/.test(phone)) {

        document.getElementById("studentPhoneError").innerHTML =
            "Enter a valid 10-digit phone number.";

        valid = false;
    }


    if (gender === "") {

        document.getElementById("studentGenderError").innerHTML =
            "Please select gender.";

        valid = false;
    }


    if (dob === "") {

        document.getElementById("studentDobError").innerHTML =
            "Date of birth is required.";

        valid = false;
    }


    if (course === "") {

        document.getElementById("studentCourseError").innerHTML =
            "Please select a course.";

        valid = false;
    }


    if (address === "") {

        document.getElementById("studentAddressError").innerHTML =
            "Address is required.";

        valid = false;
    }


    if (valid) {

        alert("Student added successfully!");

        document.getElementById("studentForm").reset();

        closeStudentForm();
    }


    return false;
}


/* ================= STUDENT SEARCH ================= */

const studentSearch =
    document.getElementById("studentSearch");

if (studentSearch) {

    studentSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll("#studentTable tbody tr");


        rows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();

            if (rowText.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= STUDENT FILTER ================= */

const studentFilter =
    document.getElementById("studentFilter");

if (studentFilter) {

    studentFilter.addEventListener("change", function () {

        const selectedStatus =
            this.value;

        const rows =
            document.querySelectorAll("#studentTable tbody tr");


        rows.forEach(function (row) {

            const statusElement =
                row.querySelector(".status");


            if (selectedStatus === "all") {
                row.style.display = "";
                return;
            }


            const status =
                statusElement.innerText.toLowerCase();


            if (status === selectedStatus) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= ROOM FORM ================= */

function openRoomForm() {

    const formPanel =
        document.getElementById("roomFormPanel");

    if (formPanel) {

        formPanel.classList.add("show");

        formPanel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


function closeRoomForm() {

    const formPanel =
        document.getElementById("roomFormPanel");

    if (formPanel) {
        formPanel.classList.remove("show");
    }
}


/* ================= ROOM VALIDATION ================= */

function validateRoomForm() {

    const roomNumber =
        document.getElementById("roomNumber").value.trim();

    const block =
        document.getElementById("roomBlock").value;

    const floor =
        document.getElementById("roomFloor").value;

    const capacity =
        document.getElementById("roomCapacity").value;

    const type =
        document.getElementById("roomType").value;

    const status =
        document.getElementById("roomStatus").value;


    document.getElementById("roomNumberError").innerHTML = "";
    document.getElementById("roomBlockError").innerHTML = "";
    document.getElementById("roomFloorError").innerHTML = "";
    document.getElementById("roomCapacityError").innerHTML = "";
    document.getElementById("roomTypeError").innerHTML = "";
    document.getElementById("roomStatusError").innerHTML = "";


    let valid = true;


    if (roomNumber === "") {

        document.getElementById("roomNumberError").innerHTML =
            "Room number is required.";

        valid = false;
    }


    if (block === "") {

        document.getElementById("roomBlockError").innerHTML =
            "Please select a block.";

        valid = false;
    }


    if (floor === "") {

        document.getElementById("roomFloorError").innerHTML =
            "Please select a floor.";

        valid = false;
    }


    if (capacity === "") {

        document.getElementById("roomCapacityError").innerHTML =
            "Please select room capacity.";

        valid = false;
    }


    if (type === "") {

        document.getElementById("roomTypeError").innerHTML =
            "Please select room type.";

        valid = false;
    }


    if (status === "") {

        document.getElementById("roomStatusError").innerHTML =
            "Please select room status.";

        valid = false;
    }


    if (valid) {

        alert("Room added successfully!");

        document.getElementById("roomForm").reset();

        closeRoomForm();
    }


    return false;
}


/* ================= ROOM SEARCH ================= */

const roomSearch =
    document.getElementById("roomSearch");

if (roomSearch) {

    roomSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll("#roomTable tbody tr");


        rows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();

            if (rowText.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= ROOM FILTER ================= */

const roomFilter =
    document.getElementById("roomFilter");

if (roomFilter) {

    roomFilter.addEventListener("change", function () {

        const selectedStatus =
            this.value;

        const rows =
            document.querySelectorAll("#roomTable tbody tr");


        rows.forEach(function (row) {

            const statusElement =
                row.querySelector(".room-status");


            if (selectedStatus === "all") {
                row.style.display = "";
                return;
            }


            const status =
                statusElement.innerText.toLowerCase();


            if (status === selectedStatus) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= ROOM ALLOCATION ================= */

function openAllocationForm() {

    const formPanel =
        document.getElementById("allocationFormPanel");

    if (formPanel) {

        formPanel.classList.add("show");

        formPanel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


function closeAllocationForm() {

    const formPanel =
        document.getElementById("allocationFormPanel");

    if (formPanel) {
        formPanel.classList.remove("show");
    }
}


/* ================= ALLOCATION VALIDATION ================= */

function validateAllocationForm() {

    const student =
        document.getElementById("allocationStudent").value;

    const room =
        document.getElementById("allocationRoom").value;

    const bed =
        document.getElementById("allocationBed").value;

    const date =
        document.getElementById("allocationDate").value;

    const duration =
        document.getElementById("allocationDuration").value;


    document.getElementById("allocationStudentError").innerHTML = "";
    document.getElementById("allocationRoomError").innerHTML = "";
    document.getElementById("allocationBedError").innerHTML = "";
    document.getElementById("allocationDateError").innerHTML = "";
    document.getElementById("allocationDurationError").innerHTML = "";


    let valid = true;


    if (student === "") {

        document.getElementById("allocationStudentError").innerHTML =
            "Please select a student.";

        valid = false;
    }


    if (room === "") {

        document.getElementById("allocationRoomError").innerHTML =
            "Please select a room.";

        valid = false;
    }


    if (bed === "") {

        document.getElementById("allocationBedError").innerHTML =
            "Please select a bed.";

        valid = false;
    }


    if (date === "") {

        document.getElementById("allocationDateError").innerHTML =
            "Please select an allocation date.";

        valid = false;
    }


    if (duration === "") {

        document.getElementById("allocationDurationError").innerHTML =
            "Please select duration.";

        valid = false;
    }


    if (valid) {

        alert("Room allocated successfully!");

        document.getElementById("allocationForm").reset();

        closeAllocationForm();
    }


    return false;
}


/* ================= ALLOCATION SEARCH ================= */

const allocationSearch =
    document.getElementById("allocationSearch");

if (allocationSearch) {

    allocationSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll("#allocationTable tbody tr");


        rows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();

            if (rowText.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= ALLOCATION FILTER ================= */

const allocationFilter =
    document.getElementById("allocationFilter");

if (allocationFilter) {

    allocationFilter.addEventListener("change", function () {

        const selectedStatus =
            this.value;

        const rows =
            document.querySelectorAll("#allocationTable tbody tr");


        rows.forEach(function (row) {

            const statusElement =
                row.querySelector(".status");


            if (selectedStatus === "all") {
                row.style.display = "";
                return;
            }


            const status =
                statusElement.innerText.toLowerCase();


            if (status === selectedStatus) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= COMPLAINT FORM ================= */

function openComplaintForm() {

    const formPanel =
        document.getElementById("complaintFormPanel");

    if (formPanel) {

        formPanel.classList.add("show");

        formPanel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


function closeComplaintForm() {

    const formPanel =
        document.getElementById("complaintFormPanel");

    if (formPanel) {
        formPanel.classList.remove("show");
    }
}


/* ================= COMPLAINT VALIDATION ================= */

function validateComplaintForm() {

    const student =
        document.getElementById("complaintStudent").value;

    const room =
        document.getElementById("complaintRoom").value.trim();

    const category =
        document.getElementById("complaintCategory").value;

    const priority =
        document.getElementById("complaintPriority").value;

    const date =
        document.getElementById("complaintDate").value;

    const status =
        document.getElementById("complaintStatus").value;

    const description =
        document.getElementById("complaintDescription").value.trim();


    document.getElementById("complaintStudentError").innerHTML = "";
    document.getElementById("complaintRoomError").innerHTML = "";
    document.getElementById("complaintCategoryError").innerHTML = "";
    document.getElementById("complaintPriorityError").innerHTML = "";
    document.getElementById("complaintDateError").innerHTML = "";
    document.getElementById("complaintStatusError").innerHTML = "";
    document.getElementById("complaintDescriptionError").innerHTML = "";


    let valid = true;


    if (student === "") {

        document.getElementById("complaintStudentError").innerHTML =
            "Please select a student.";

        valid = false;
    }


    if (room === "") {

        document.getElementById("complaintRoomError").innerHTML =
            "Room number is required.";

        valid = false;
    }


    if (category === "") {

        document.getElementById("complaintCategoryError").innerHTML =
            "Please select a category.";

        valid = false;
    }


    if (priority === "") {

        document.getElementById("complaintPriorityError").innerHTML =
            "Please select priority.";

        valid = false;
    }


    if (date === "") {

        document.getElementById("complaintDateError").innerHTML =
            "Please select complaint date.";

        valid = false;
    }


    if (status === "") {

        document.getElementById("complaintStatusError").innerHTML =
            "Please select status.";

        valid = false;
    }


    if (description === "") {

        document.getElementById("complaintDescriptionError").innerHTML =
            "Complaint description is required.";

        valid = false;
    }


    if (valid) {

        alert("Complaint added successfully!");

        document.getElementById("complaintForm").reset();

        closeComplaintForm();
    }


    return false;
}


/* ================= COMPLAINT SEARCH ================= */

const complaintSearch =
    document.getElementById("complaintSearch");

if (complaintSearch) {

    complaintSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll("#complaintTable tbody tr");


        rows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();

            if (rowText.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= COMPLAINT FILTER ================= */

const complaintFilter =
    document.getElementById("complaintFilter");

if (complaintFilter) {

    complaintFilter.addEventListener("change", function () {

        const selectedStatus =
            this.value;

        const rows =
            document.querySelectorAll("#complaintTable tbody tr");


        rows.forEach(function (row) {

            const statusElement =
                row.querySelector(".status");


            if (selectedStatus === "all") {
                row.style.display = "";
                return;
            }


            const status =
                statusElement.innerText.toLowerCase();


            if (status === selectedStatus) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= VISITOR FORM ================= */

function openVisitorForm() {

    const formPanel =
        document.getElementById("visitorFormPanel");

    if (formPanel) {

        formPanel.classList.add("show");

        formPanel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


function closeVisitorForm() {

    const formPanel =
        document.getElementById("visitorFormPanel");

    if (formPanel) {
        formPanel.classList.remove("show");
    }
}


/* ================= VISITOR VALIDATION ================= */

function validateVisitorForm() {

    const name =
        document.getElementById("visitorName").value.trim();

    const student =
        document.getElementById("visitorStudent").value;

    const relation =
        document.getElementById("visitorRelation").value;

    const phone =
        document.getElementById("visitorPhone").value.trim();

    const date =
        document.getElementById("visitorDate").value;

    const checkIn =
        document.getElementById("checkIn").value;

    const purpose =
        document.getElementById("visitorPurpose").value.trim();


    document.getElementById("visitorNameError").innerHTML = "";
    document.getElementById("visitorStudentError").innerHTML = "";
    document.getElementById("visitorRelationError").innerHTML = "";
    document.getElementById("visitorPhoneError").innerHTML = "";
    document.getElementById("visitorDateError").innerHTML = "";
    document.getElementById("checkInError").innerHTML = "";
    document.getElementById("visitorPurposeError").innerHTML = "";


    let valid = true;


    if (name === "") {

        document.getElementById("visitorNameError").innerHTML =
            "Visitor name is required.";

        valid = false;
    }


    if (student === "") {

        document.getElementById("visitorStudentError").innerHTML =
            "Please select a student.";

        valid = false;
    }


    if (relation === "") {

        document.getElementById("visitorRelationError").innerHTML =
            "Please select relationship.";

        valid = false;
    }


    if (!/^[0-9]{10}$/.test(phone)) {

        document.getElementById("visitorPhoneError").innerHTML =
            "Enter a valid 10-digit contact number.";

        valid = false;
    }


    if (date === "") {

        document.getElementById("visitorDateError").innerHTML =
            "Please select visit date.";

        valid = false;
    }


    if (checkIn === "") {

        document.getElementById("checkInError").innerHTML =
            "Please select check-in time.";

        valid = false;
    }


    if (purpose === "") {

        document.getElementById("visitorPurposeError").innerHTML =
            "Purpose of visit is required.";

        valid = false;
    }


    if (valid) {

        alert("Visitor added successfully!");

        document.getElementById("visitorForm").reset();

        closeVisitorForm();
    }


    return false;
}


/* ================= VISITOR SEARCH ================= */

const visitorSearch =
    document.getElementById("visitorSearch");

if (visitorSearch) {

    visitorSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll("#visitorTable tbody tr");


        rows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();

            if (rowText.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= VISITOR FILTER ================= */

const visitorFilter =
    document.getElementById("visitorFilter");

if (visitorFilter) {

    visitorFilter.addEventListener("change", function () {

        const selectedStatus =
            this.value;

        const rows =
            document.querySelectorAll("#visitorTable tbody tr");


        rows.forEach(function (row) {

            const statusElement =
                row.querySelector(".status");


            if (selectedStatus === "all") {
                row.style.display = "";
                return;
            }


            const status =
                statusElement.innerText.toLowerCase();


            if (selectedStatus === status) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= PAYMENT FORM ================= */

function openPaymentForm() {

    const formPanel =
        document.getElementById("paymentFormPanel");

    if (formPanel) {

        formPanel.classList.add("show");

        formPanel.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


function closePaymentForm() {

    const formPanel =
        document.getElementById("paymentFormPanel");

    if (formPanel) {
        formPanel.classList.remove("show");
    }
}


/* ================= PAYMENT VALIDATION ================= */

function validatePaymentForm() {

    const student =
        document.getElementById("paymentStudent").value;

    const room =
        document.getElementById("paymentRoom").value.trim();

    const amount =
        document.getElementById("paymentAmount").value;

    const date =
        document.getElementById("paymentDate").value;

    const method =
        document.getElementById("paymentMethod").value;

    const status =
        document.getElementById("paymentStatus").value;


    document.getElementById("paymentStudentError").innerHTML = "";
    document.getElementById("paymentRoomError").innerHTML = "";
    document.getElementById("paymentAmountError").innerHTML = "";
    document.getElementById("paymentDateError").innerHTML = "";
    document.getElementById("paymentMethodError").innerHTML = "";
    document.getElementById("paymentStatusError").innerHTML = "";


    let valid = true;


    if (student === "") {

        document.getElementById("paymentStudentError").innerHTML =
            "Please select a student.";

        valid = false;
    }


    if (room === "") {

        document.getElementById("paymentRoomError").innerHTML =
            "Room number is required.";

        valid = false;
    }


    if (amount === "" || Number(amount) <= 0) {

        document.getElementById("paymentAmountError").innerHTML =
            "Enter a valid payment amount.";

        valid = false;
    }


    if (date === "") {

        document.getElementById("paymentDateError").innerHTML =
            "Please select payment date.";

        valid = false;
    }


    if (method === "") {

        document.getElementById("paymentMethodError").innerHTML =
            "Please select payment method.";

        valid = false;
    }


    if (status === "") {

        document.getElementById("paymentStatusError").innerHTML =
            "Please select payment status.";

        valid = false;
    }


    if (valid) {

        alert("Payment added successfully!");

        document.getElementById("paymentForm").reset();

        closePaymentForm();
    }


    return false;
}


/* ================= PAYMENT SEARCH ================= */

const paymentSearch =
    document.getElementById("paymentSearch");

if (paymentSearch) {

    paymentSearch.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase();

        const rows =
            document.querySelectorAll("#paymentTable tbody tr");


        rows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();

            if (rowText.includes(searchText)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= PAYMENT FILTER ================= */

const paymentFilter =
    document.getElementById("paymentFilter");

if (paymentFilter) {

    paymentFilter.addEventListener("change", function () {

        const selectedStatus =
            this.value;

        const rows =
            document.querySelectorAll("#paymentTable tbody tr");


        rows.forEach(function (row) {

            const statusElement =
                row.querySelector(".status");


            if (selectedStatus === "all") {
                row.style.display = "";
                return;
            }


            const status =
                statusElement.innerText.toLowerCase();


            if (status === selectedStatus) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    });
}


/* ================= STUDENT DASHBOARD ================= */

// Mobile sidebar toggle

const menuBtn =
    document.querySelector(".menu-btn");

const sidebar =
    document.querySelector(".sidebar");


if (menuBtn && sidebar) {

    menuBtn.addEventListener("click", function () {

        sidebar.classList.toggle("active");

    });
}


// Close sidebar when menu item is clicked

const sidebarLinks =
    document.querySelectorAll(".sidebar a");


sidebarLinks.forEach(function (link) {

    link.addEventListener("click", function () {

        if (window.innerWidth <= 900 && sidebar) {

            sidebar.classList.remove("active");

        }

    });

});


// Search in student dashboard

const searchInput =
    document.querySelector(".search-box input");


if (searchInput) {

    searchInput.addEventListener("keyup", function () {

        const searchText =
            searchInput.value.toLowerCase();


        const dashboardCards =
            document.querySelectorAll(
                ".student-dashboard-grid .card"
            );


        dashboardCards.forEach(function (card) {

            const cardText =
                card.innerText.toLowerCase();


            if (cardText.includes(searchText)) {

                card.style.display = "";

            } else {

                card.style.display = "none";

            }

        });

    });

}


// Notification button

const notificationButton =
    document.querySelector(".notification");


if (notificationButton) {

    notificationButton.addEventListener("click", function () {

        alert("You have 3 new notifications.");

    });

}


// Quick action buttons

const quickActions =
    document.querySelectorAll(".quick-action");


quickActions.forEach(function (action) {

    action.addEventListener("click", function () {

        const actionName =
            action.innerText.trim();


        if (actionName.includes("Complaint")) {

            window.location.href =
                "my-complaints.html";

        }

        else if (actionName.includes("Visitor")) {

            window.location.href =
                "my-visitors.html";

        }

        else if (actionName.includes("Payment")) {

            window.location.href =
                "my-payments.html";

        }

        else if (actionName.includes("Profile")) {

            window.location.href =
                "student-profile.html";

        }

    });

});


// View Room button

const roomLink =
    document.querySelector(
        ".room-summary .view-link"
    );


if (roomLink) {

    roomLink.addEventListener("click", function (event) {

        event.preventDefault();

        window.location.href =
            "my-room.html";

    });

}


// View Payment button

const paymentLink =
    document.querySelector(
        ".payment-summary .view-link"
    );


if (paymentLink) {

    paymentLink.addEventListener("click", function (event) {

        event.preventDefault();

        window.location.href =
            "my-payments.html";

    });

}


// View Complaint button

const complaintLink =
    document.querySelector(
        ".student-complaint .view-link"
    );


if (complaintLink) {

    complaintLink.addEventListener("click", function (event) {

        event.preventDefault();

        window.location.href =
            "my-complaints.html";

    });

}


// Logout confirmation

const logoutLinks =
    document.querySelectorAll(
        'a[href="login.html"]'
    );


logoutLinks.forEach(function (logout) {

    logout.addEventListener("click", function (event) {

        const confirmLogout =
            confirm("Are you sure you want to logout?");


        if (!confirmLogout) {

            event.preventDefault();

        }

    });

});


/* ================= PROFILE PAGE ================= */

const profileForm =
    document.getElementById("studentProfileForm");

const cancelButton =
    document.getElementById("cancelProfile");


// Save profile

if (profileForm) {

    profileForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            const name =
                document.getElementById("studentName").value.trim();

            const email =
                document.getElementById("email").value.trim();

            const phone =
                document.getElementById("phone").value.trim();

            const emergencyContact =
                document.getElementById("emergencyContact").value.trim();


            if (name === "") {

                alert("Please enter your name.");
                return;

            }


            if (email === "") {

                alert("Please enter your email.");
                return;

            }


            if (phone.length !== 10 || isNaN(phone)) {

                alert(
                    "Please enter a valid 10-digit phone number."
                );

                return;

            }


            if (
                emergencyContact.length !== 10 ||
                isNaN(emergencyContact)
            ) {

                alert(
                    "Please enter a valid 10-digit emergency contact number."
                );

                return;

            }


            alert("Profile updated successfully!");

        }
    );

}


// Cancel changes

if (cancelButton) {

    cancelButton.addEventListener("click", function () {

        const confirmCancel =
            confirm(
                "Are you sure you want to discard your changes?"
            );


        if (confirmCancel && profileForm) {

            profileForm.reset();

        }

    });

}


/* ================= STUDENT MY ROOM ================= */

const roomInfoButton =
    document.getElementById("roomInfoButton");


if (roomInfoButton) {

    roomInfoButton.addEventListener("click", function () {

        alert(
            "Room A-102\n\n" +
            "Block: A\n" +
            "Floor: 1st Floor\n" +
            "Room Type: Triple Sharing\n" +
            "Bed: B2\n" +
            "Status: Allocated"
        );

    });

}


/* ================= STUDENT COMPLAINTS ================= */

const openComplaintForm =
    document.getElementById("openComplaintForm");

const complaintFormSection =
    document.getElementById("complaintFormSection");

const complaintForm =
    document.getElementById("complaintForm");


// Scroll to complaint form

if (openComplaintForm && complaintFormSection) {

    openComplaintForm.addEventListener("click", function () {

        complaintFormSection.scrollIntoView({
            behavior: "smooth"
        });

    });

}


// Submit complaint

if (complaintForm) {

    complaintForm.addEventListener("submit", function (event) {

        event.preventDefault();


        const category =
            document.getElementById("complaintCategory").value;

        const priority =
            document.getElementById("complaintPriority").value;

        const subject =
            document.getElementById("complaintSubject").value.trim();

        const description =
            document.getElementById("complaintDescription").value.trim();


        if (category === "") {

            alert("Please select a complaint category.");
            return;

        }


        if (priority === "") {

            alert("Please select the complaint priority.");
            return;

        }


        if (subject === "") {

            alert("Please enter the complaint subject.");
            return;

        }


        if (description === "") {

            alert("Please describe your complaint.");
            return;

        }


        if (description.length < 10) {

            alert(
                "Please provide a little more information about the problem."
            );

            return;

        }


        alert(
            "Complaint submitted successfully!\n\n" +
            "Category: " + category + "\n" +
            "Priority: " + priority
        );


        complaintForm.reset();

    });

}


/* ================= STUDENT VISITORS ================= */

const openVisitorForm =
    document.getElementById("openVisitorForm");

const visitorFormSection =
    document.getElementById("visitorFormSection");

const visitorForm =
    document.getElementById("visitorForm");


// Open visitor form

if (openVisitorForm && visitorFormSection) {

    openVisitorForm.addEventListener("click", function () {

        visitorFormSection.scrollIntoView({
            behavior: "smooth"
        });

    });

}


// Set today's date

const visitDate =
    document.getElementById("visitDate");


if (visitDate) {

    const today =
        new Date();

    const year =
        today.getFullYear();

    const month =
        String(today.getMonth() + 1).padStart(2, "0");

    const day =
        String(today.getDate()).padStart(2, "0");


    visitDate.value =
        year + "-" + month + "-" + day;

}


// Submit visitor form

if (visitorForm) {

    visitorForm.addEventListener("submit", function (event) {

        event.preventDefault();


        const name =
            document.getElementById("visitorName").value.trim();

        const relation =
            document.getElementById("visitorRelation").value;

        const phone =
            document.getElementById("visitorPhone").value.trim();

        const date =
            document.getElementById("visitDate").value;

        const time =
            document.getElementById("entryTime").value;

        const purpose =
            document.getElementById("visitPurpose").value.trim();


        if (name === "") {

            alert("Please enter visitor name.");
            return;

        }


        if (relation === "") {

            alert("Please select visitor relation.");
            return;

        }


        if (phone.length !== 10 || isNaN(phone)) {

            alert("Please enter a valid 10-digit phone number.");
            return;

        }


        if (date === "") {

            alert("Please select visit date.");
            return;

        }


        if (time === "") {

            alert("Please select expected entry time.");
            return;

        }


        if (purpose === "") {

            alert("Please enter the purpose of visit.");
            return;

        }


        alert(
            "Visitor added successfully!\n\n" +
            "Name: " + name + "\n" +
            "Relation: " + relation + "\n" +
            "Date: " + date
        );


        visitorForm.reset();

    });

}


/* ================= STUDENT PAYMENTS ================= */

// Payment search

const paymentSearchInput =
    document.getElementById("paymentSearch");


if (paymentSearchInput) {

    paymentSearchInput.addEventListener("keyup", function () {

        const searchText =
            paymentSearchInput.value.toLowerCase();


        const paymentRows =
            document.querySelectorAll(
                ".student-payment-table tbody tr"
            );


        paymentRows.forEach(function (row) {

            const rowText =
                row.innerText.toLowerCase();


            if (rowText.includes(searchText)) {

                row.style.display = "";

            } else {

                row.style.display = "none";

            }

        });

    });

}


// View receipt

const receiptButtons =
    document.querySelectorAll(".receipt-btn");


receiptButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        const transactionId =
            button.getAttribute("data-transaction");


        alert(
            "Payment Receipt\n\n" +
            "Transaction ID: " + transactionId + "\n" +
            "Student: Riya Sharma\n" +
            "Student ID: ST001\n" +
            "Room: A-102\n" +
            "Status: Paid\n\n" +
            "Receipt viewing will be connected to the backend later."
        );

    });

});


// Payment notification

const paymentNotification =
    document.getElementById("paymentNotification");


if (paymentNotification) {

    paymentNotification.addEventListener("click", function () {

        alert(
            "No new payment notifications.\n\n" +
            "Your hostel fee is completely paid."
        );

    });

}