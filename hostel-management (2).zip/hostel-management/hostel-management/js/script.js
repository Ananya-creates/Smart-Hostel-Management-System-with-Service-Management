/* ============================================
   Hostel Management System — Shared Script
   ============================================ */

// Global fetch wrapper: always send session cookie
const __origFetch = window.fetch;
window.fetch = function (url, opts = {}) {
    opts.credentials = opts.credentials || 'same-origin';
    return __origFetch(url, opts);
};

const TOTAL_FEE = 60000;

// ---------- AUTH ----------
let __sessionCache = null;

async function loadSession() {
    if (__sessionCache) return __sessionCache;
    try {
        const r = await fetch('api/auth.php?action=session');
        const d = await r.json();
        __sessionCache = d.user || null;
    } catch {
        __sessionCache = null;
    }
    return __sessionCache;
}

function getSession() { return __sessionCache; }

async function logout() {
    try { await fetch('api/auth.php?action=logout'); } catch {}
    __sessionCache = null;
    window.location.href = 'login.html';
}

async function requireAuth(role) {
    const s = await loadSession();
    if (!s) { window.location.href = 'login.html'; return null; }
    if (role && s.role !== role) {
        window.location.href = s.role === 'admin' ? 'dashboard.html' : 'student-dashboard.html';
        return null;
    }
    return s;
}

async function withAuth(role, fn) {
    const s = await requireAuth(role);
    if (!s) return;
    await fn(s);
}

// ---------- UI HELPERS ----------
function toast(msg, type) {
    let t = document.getElementById('hms-toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'hms-toast';
        t.className = 'toast';
        document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = 'toast ' + (type || '') + ' show';
    setTimeout(() => t.className = 'toast ' + (type || ''), 2400);
}

function badge(status) {
    const map = {
        'Active': 'success', 'Paid': 'success', 'Resolved': 'success',
        'Available': 'success', 'Checked Out': 'neutral',
        'Pending': 'warning', 'Partial': 'warning', 'In Progress': 'warning',
        'Inside Hostel': 'info',
        'Full': 'danger', 'Vacant': 'info', 'Blocked': 'danger',
        'High': 'danger', 'Medium': 'warning', 'Low': 'info'
    };
    return '<span class="badge badge-' + (map[status] || 'neutral') + '">' + status + '</span>';
}

function initials(name) {
    return name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();
}

function fmtDate(d) {
    if (!d) return '-';
    const dt = new Date(d);
    return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtMoney(n) { return '\u20B9' + Number(n).toLocaleString('en-IN'); }

// ---------- SIDEBAR ----------
function toggleSidebar() {
    const sb = document.querySelector('.sidebar');
    const ov = document.querySelector('.sidebar-overlay');
    if (sb) sb.classList.toggle('open');
    if (ov) ov.classList.toggle('show');
}

function renderLayout(role, activeKey, pageTitle, pageSub) {
    const s = getSession();
    const uName = s ? s.name : (role === 'admin' ? 'Administrator' : 'Student');
    const uRole = role === 'admin' ? 'ADMIN' : 'STUDENT';

    const adminMenu = [
        { k: 'dashboard',  label: 'Dashboard',       ico: '\u25A6', href: 'dashboard.html' },
        { k: 'students',   label: 'Students',        ico: '\u2632', href: 'students.html' },
        { k: 'rooms',      label: 'Rooms',           ico: '\u25A3', href: 'rooms.html' },
        { k: 'allocation', label: 'Room Allocation', ico: '\u2691', href: 'room-allocation.html' },
        { k: 'complaints', label: 'Complaints',      ico: '\u26A0', href: 'complaints.html' },
        { k: 'visitors',   label: 'Visitors',        ico: '\u263A', href: 'visitors.html' },
        { k: 'payments',   label: 'Payments',        ico: '\u20B9', href: 'payments.html' }
    ];
    const studentMenu = [
        { k: 'dashboard',     label: 'Dashboard',     ico: '\u25A6', href: 'student-dashboard.html' },
        { k: 'profile',       label: 'My Profile',    ico: '\u263A', href: 'student-profile.html' },
        { k: 'room',          label: 'My Room',       ico: '\u25A3', href: 'my-room.html' },
        { k: 'complaints',    label: 'My Complaints', ico: '\u26A0', href: 'my-complaints.html' },
        { k: 'visitors',      label: 'My Visitors',   ico: '\u2691', href: 'my-visitors.html' },
        { k: 'payments',      label: 'My Payments',   ico: '\u20B9', href: 'my-payments.html' },
        { k: 'notifications', label: 'Notifications', ico: '\u2709', href: 'notifications.html' }
    ];
    const menu = role === 'admin' ? adminMenu : studentMenu;

    const menuHtml = menu.map(m =>
        '<a href="' + m.href + '" class="nav-item ' + (m.k === activeKey ? 'active' : '') + '">' +
        '<span class="ico">' + m.ico + '</span>' + m.label +
        '</a>').join('');

    document.body.innerHTML =
        '<div class="sidebar-overlay" onclick="toggleSidebar()"></div>' +
        '<div class="layout">' +
            '<aside class="sidebar">' +
                '<div class="brand">' +
                    '<div class="brand-logo">H</div>' +
                    '<div>Hostel MS<span class="role-tag">' + uRole + '</span></div>' +
                '</div>' +
                '<div class="menu-label">Menu</div>' +
                menuHtml +
                '<div class="logout-block">' +
                    '<a href="#" class="nav-item" onclick="logout();return false;">' +
                        '<span class="ico">\u2B8C</span>Logout' +
                    '</a>' +
                '</div>' +
            '</aside>' +
            '<div>' +
                '<header class="topbar">' +
                    '<div style="display:flex;align-items:center;gap:12px;">' +
                        '<button class="hamburger" onclick="toggleSidebar()">\u2630</button>' +
                        '<div class="page-title">' + pageTitle + '<small>' + (pageSub || '') + '</small></div>' +
                    '</div>' +
                    '<div class="user-chip">' +
                        '<span class="avatar">' + initials(uName) + '</span>' +
                        '<span class="u-name">' + uName + '</span>' +
                    '</div>' +
                '</header>' +
                '<main class="main" id="page-main"></main>' +
            '</div>' +
        '</div>';
}

// ---------- MODAL ----------
function openModal(title, bodyHtml, onSubmit, submitLabel) {
    let m = document.getElementById('hms-modal');
    if (!m) {
        m = document.createElement('div');
        m.id = 'hms-modal';
        m.className = 'modal-backdrop';
        document.body.appendChild(m);
    }
    m.innerHTML =
        '<div class="modal">' +
            '<div class="modal-head">' +
                '<h3>' + title + '</h3>' +
                '<button class="modal-close" onclick="closeModal()">&times;</button>' +
            '</div>' +
            '<form id="hms-modal-form" method="POST">' +
                '<div class="modal-body">' + bodyHtml + '</div>' +
                '<div class="modal-foot">' +
                    '<button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>' +
                    '<button type="submit" class="btn btn-primary">' + (submitLabel || 'Save') + '</button>' +
                '</div>' +
            '</form>' +
        '</div>';
    m.classList.add('show');
    document.getElementById('hms-modal-form').addEventListener('submit', e => {
        e.preventDefault();
        const data = {};
        new FormData(e.target).forEach((v, k) => data[k] = v);
        onSubmit(data);
    });
}

function closeModal() {
    const m = document.getElementById('hms-modal');
    if (m) m.classList.remove('show');
}

// ---------- PASSWORD TOGGLE ----------
function togglePassword(inputId, btn) {
    const inp = document.getElementById(inputId);
    if (inp.type === 'password') { inp.type = 'text'; btn.textContent = 'HIDE'; }
    else { inp.type = 'password'; btn.textContent = 'SHOW'; }
}