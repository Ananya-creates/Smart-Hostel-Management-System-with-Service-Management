<?php
require_once _DIR_ . '/helpers.php';
$user = requireLogin('student');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$user['studentId']]);
    $row = $stmt->fetch();
    if ($row) unset($row['password']);
    sendJson($row);
}

if ($method === 'PUT') {
    $d = getJsonInput();
    $stmt = $pdo->prepare(
        "UPDATE students SET name=?, email=?, phone=?, course=? WHERE id=?"
    );
    $stmt->execute([
        $d['name'], $d['email'], $d['phone'],
        $d['course'], $user['studentId'],
    ]);
    sendJson(['success' => true]);
}