<?php
require_once _DIR_ . '/helpers.php';
requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    sendJson($pdo->query("SELECT * FROM notifications ORDER BY id")->fetchAll());
}

if ($method === 'PUT') {
    $d = getJsonInput();
    if (!empty($d['all'])) {
        $pdo->query("UPDATE notifications SET is_read=1");
    } else {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read=1 WHERE id=?");
        $stmt->execute([$d['id']]);
    }
    sendJson(['success' => true]);
}