<?php
require_once __DIR__ . '/helpers.php';

$action = $_GET['action'] ?? '';

// ---------- LOGIN ----------
if ($action === 'login') {
    $data  = getJsonInput();
    $role  = $data['role']     ?? '';
    $email = trim($data['email'] ?? '');
    $pwd   = $data['password'] ?? '';

    if (!$role || !$email || !$pwd) sendError('Missing fields');

    if ($role === 'admin') {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($pwd, $admin['password'])) {
            establishSession([
                'role'  => 'admin',
                'email' => $admin['email'],
                'name'  => $admin['name'],
            ]);
            sendJson([
                'success'  => true,
                'redirect' => 'dashboard.html',
                'role'     => 'admin',
                'name'     => $admin['name'],
                'email'    => $admin['email'],
            ]);
        }
        sendError('Invalid admin credentials', 401);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM students WHERE email = ?");
        $stmt->execute([$email]);
        $stu = $stmt->fetch();

        if ($stu && password_verify($pwd, $stu['password'])) {
            establishSession([
                'role'      => 'student',
                'email'     => $stu['email'],
                'name'      => $stu['name'],
                'studentId' => $stu['id'],
            ]);
            sendJson([
                'success'   => true,
                'redirect'  => 'student-dashboard.html',
                'role'      => 'student',
                'name'      => $stu['name'],
                'email'     => $stu['email'],
                'studentId' => $stu['id'],
            ]);
        }
        sendError('Invalid student credentials', 401);
    }
}

// ---------- REGISTER ----------
if ($action === 'register') {
    $d     = getJsonInput();
    $id    = trim($d['studentId'] ?? '');
    $name  = trim($d['fullname']  ?? '');
    $email = trim($d['email']     ?? '');
    $phone = trim($d['phone']     ?? '');
    $pwd   = $d['password']       ?? '';

    if (!$id || !$name || !$email || !$pwd) sendError('Missing fields');

    $stmt = $pdo->prepare("SELECT id FROM students WHERE email = ? OR id = ?");
    $stmt->execute([$email, $id]);
    if ($stmt->fetch()) sendError('Email or Student ID already registered');

    $hash = password_hash($pwd, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare(
        "INSERT INTO students (id, name, email, password, phone, gender, course, year, room, status)
         VALUES (?, ?, ?, ?, ?, '-', '-', '-', '', 'Pending')"
    );
    $stmt->execute([$id, $name, $email, $hash, $phone]);

    sendJson(['success' => true]);
}

// ---------- LOGOUT ----------
if ($action === 'logout') {
    destroySession();
    sendJson(['success' => true]);
}

// ---------- SESSION CHECK ----------
if ($action === 'session') {
    sendJson(['user' => $_SESSION['user'] ?? null]);
}

sendError('Unknown action', 404);