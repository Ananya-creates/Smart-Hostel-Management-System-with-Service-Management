<?php
// ============================================
// Common helper functions
// ============================================

// ---------- Secure session configuration ----------
ini_set('session.use_strict_mode', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'domain'   => '',
    'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
    'httponly' => true,
    'samesite' => 'Lax',
]);

session_start();

// Idle timeout: 30 minutes
$SESSION_TIMEOUT = 1800;
if (isset($_SESSION['LAST_ACTIVITY']) &&
    (time() - $_SESSION['LAST_ACTIVITY']) > $SESSION_TIMEOUT) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    session_start();
}
$_SESSION['LAST_ACTIVITY'] = time();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/db.php';

function getJsonInput() {
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function sendJson($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function sendError($msg, $code = 400) {
    http_response_code($code);
    echo json_encode(['error' => $msg]);
    exit;
}

function requireLogin($role = null) {
    if (!isset($_SESSION['user'])) {
        sendError('Not authenticated', 401);
    }
    if ($role && $_SESSION['user']['role'] !== $role) {
        sendError('Forbidden', 403);
    }
    return $_SESSION['user'];
}

function establishSession(array $user) {
    session_regenerate_id(true);
    $_SESSION['user']          = $user;
    $_SESSION['LAST_ACTIVITY'] = time();
}

function destroySession() {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function requireOwnership($pdo, $table, $idColumn, $id, $studentId) {
    $stmt = $pdo->prepare("SELECT student_id FROM {$table} WHERE {$idColumn} = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) sendError('Record not found', 404);
    if ($row['student_id'] !== $studentId) sendError('Forbidden', 403);
    return $row;
}