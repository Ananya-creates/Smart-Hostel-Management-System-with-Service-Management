-- ============================================================
-- HOSTEL MANAGEMENT SYSTEM — COMPLETE DATABASE
-- Paste this whole thing in MySQL Workbench and click ⚡
-- ============================================================

DROP DATABASE IF EXISTS hostel_ms;
CREATE DATABASE hostel_ms
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE hostel_ms;

-- ============================================================
-- TABLE 1: ADMIN
-- ============================================================
CREATE TABLE Admin (
    admin_id  INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(50)  NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,
    email     VARCHAR(120) NOT NULL UNIQUE
);

-- ============================================================
-- TABLE 2: STUDENT
-- ============================================================
CREATE TABLE Student (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(120) NOT NULL UNIQUE,
    phone      VARCHAR(15),
    gender     VARCHAR(10),
    course     VARCHAR(80),
    year       INT,
    password   VARCHAR(255) NOT NULL,
    status     VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 3: ROOM
-- ============================================================
CREATE TABLE Room (
    room_id     INT AUTO_INCREMENT PRIMARY KEY,
    admin_id    INT,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    block       VARCHAR(5),
    floor       VARCHAR(20),
    capacity    INT NOT NULL DEFAULT 1,
    occupied    INT NOT NULL DEFAULT 0,
    status      VARCHAR(20) DEFAULT 'Vacant',
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE 4: ROOM_ALLOCATION
-- ============================================================
CREATE TABLE Room_Allocation (
    allocation_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id      INT NOT NULL,
    room_id         INT NOT NULL,
    allocation_date DATE NOT NULL,
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (room_id)    REFERENCES Room(room_id)       ON DELETE CASCADE
);

-- ============================================================
-- TABLE 5: FEE
-- ============================================================
CREATE TABLE Fee (
    fee_id         INT AUTO_INCREMENT PRIMARY KEY,
    student_id     INT NOT NULL,
    amount         DECIMAL(10,2) NOT NULL,
    due_date       DATE,
    payment_status VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE 6: LAUNDRY_REQUEST
-- ============================================================
CREATE TABLE Laundry_Request (
    laundry_id    INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT NOT NULL,
    clothes_count INT NOT NULL DEFAULT 0,
    request_date  DATE NOT NULL,
    status        VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE 7: MESS_MENU
-- ============================================================
CREATE TABLE Mess_Menu (
    menu_id   INT AUTO_INCREMENT PRIMARY KEY,
    admin_id  INT,
    day       VARCHAR(15) NOT NULL,
    breakfast VARCHAR(150),
    lunch     VARCHAR(150),
    snacks    VARCHAR(150),
    dinner    VARCHAR(150),
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE 8: MAINTENANCE_REQUEST
-- ============================================================
CREATE TABLE Maintenance_Request (
    request_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT NOT NULL,
    issue_type   VARCHAR(50),
    description  TEXT,
    priority     VARCHAR(15) DEFAULT 'Medium',
    status       VARCHAR(20) DEFAULT 'Pending',
    request_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE 9: LEAVE_APPLICATION
-- ============================================================
CREATE TABLE Leave_Application (
    leave_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    from_date  DATE NOT NULL,
    to_date    DATE NOT NULL,
    reason     TEXT,
    status     VARCHAR(20) DEFAULT 'Pending',
    applied_on DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE 10: NOTICE
-- ============================================================
CREATE TABLE Notice (
    notice_id    INT AUTO_INCREMENT PRIMARY KEY,
    admin_id     INT,
    title        VARCHAR(150) NOT NULL,
    description  TEXT,
    publish_date DATE NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE 11: VISITOR
-- ============================================================
CREATE TABLE Visitor (
    visitor_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT NOT NULL,
    visitor_name VARCHAR(100) NOT NULL,
    relation     VARCHAR(30),
    visit_date   DATE NOT NULL,
    time_in      TIME,
    time_out     TIME,
    status       VARCHAR(20) DEFAULT 'Inside Hostel',
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);

-- ============================================================
-- SAMPLE DATA
-- ============================================================

INSERT INTO Admin (username, password, email) VALUES
('admin', 'admin123', 'admin@hostel.com');

INSERT INTO Student (name, email, phone, gender, course, year, password, status) VALUES
('Riya Sharma',  'riya@hostel.com',   '9876543210', 'Female', 'B.Tech CSE',   3, 'student123', 'Active'),
('Arjun Kumar',  'arjun@hostel.com',  '9876501112', 'Male',   'B.Tech IT',    3, 'student123', 'Active'),
('Neha Patil',   'neha@hostel.com',   '9812345678', 'Female', 'B.Sc Physics', 2, 'student123', 'Active'),
('Aditya Rao',   'aditya@hostel.com', '9900112233', 'Male',   'B.Tech ECE',   1, 'student123', 'Active'),
('Sneha Iyer',   'sneha@hostel.com',  '9911223344', 'Female', 'BBA',          2, 'student123', 'Active');

INSERT INTO Room (admin_id, room_number, block, floor, capacity, occupied, status) VALUES
(1, 'A-101', 'A', '1st Floor', 2, 2, 'Full'),
(1, 'A-102', 'A', '1st Floor', 3, 2, 'Available'),
(1, 'A-103', 'A', '1st Floor', 2, 1, 'Available'),
(1, 'B-201', 'B', '2nd Floor', 3, 2, 'Available'),
(1, 'B-208', 'B', '2nd Floor', 1, 1, 'Full'),
(1, 'C-105', 'C', '1st Floor', 2, 1, 'Available'),
(1, 'C-110', 'C', '1st Floor', 3, 1, 'Available'),
(1, 'C-115', 'C', '1st Floor', 2, 0, 'Vacant');

INSERT INTO Room_Allocation (student_id, room_id, allocation_date) VALUES
(1, 2, '2026-07-01'),
(2, 2, '2026-07-01'),
(3, 1, '2026-07-02'),
(4, 1, '2026-07-05'),
(5, 6, '2026-07-08');

INSERT INTO Fee (student_id, amount, due_date, payment_status) VALUES
(1, 60000, '2026-11-15', 'Paid'),
(2, 60000, '2026-11-15', 'Paid'),
(3, 60000, '2026-11-15', 'Partial'),
(4, 60000, '2026-11-15', 'Paid'),
(5, 60000, '2026-11-15', 'Partial');

INSERT INTO Mess_Menu (admin_id, day, breakfast, lunch, snacks, dinner) VALUES
(1, 'Monday',    'Poha + Tea',     'Dal, Rice, Roti, Sabzi', 'Samosa + Tea',   'Paneer, Roti, Rice'),
(1, 'Tuesday',   'Idli + Sambar',  'Rajma, Rice, Roti',      'Biscuits + Tea', 'Mix Veg, Roti, Rice'),
(1, 'Wednesday', 'Paratha + Curd', 'Chole, Rice, Roti',      'Vada + Tea',     'Aloo Gobi, Roti, Rice'),
(1, 'Thursday',  'Upma + Tea',     'Kadhi, Rice, Roti',      'Pav Bhaji',      'Dal Fry, Roti, Rice'),
(1, 'Friday',    'Puri + Sabzi',   'Paneer, Rice, Roti',     'Fruit Chaat',    'Rajma, Roti, Rice'),
(1, 'Saturday',  'Dosa + Chutney', 'Veg Biryani',            'Chips + Tea',    'Chole, Roti, Rice'),
(1, 'Sunday',    'Aloo Puri',      'Special Thali',          'Ice Cream',      'Fried Rice + Manchurian');

INSERT INTO Notice (admin_id, title, description, publish_date) VALUES
(1, 'Fee Payment Reminder',
    'Next semester fee due on 15 Nov 2026. Late fees apply after due date.',
    '2026-09-01'),
(1, 'Diwali Holiday Schedule',
    'Modified visitor timings from 05 Nov to 10 Nov. No leave approved during this period.',
    '2026-10-25'),
(1, 'Room Inspection',
    'Monthly room inspection on 20 Sep 2026, 10 AM - 1 PM.',
    '2026-09-15');

INSERT INTO Maintenance_Request (student_id, issue_type, description, priority, status) VALUES
(1, 'Electrical',  'Ceiling fan in A-102 stopped rotating.',       'High',   'In Progress'),
(4, 'Internet',    'Wi-Fi is very slow in B-201 in the evening.',  'High',   'Pending'),
(5, 'Maintenance', 'Window latch is broken in C-105.',             'Medium', 'In Progress');

INSERT INTO Leave_Application (student_id, from_date, to_date, reason, status) VALUES
(1, '2026-10-20', '2026-10-23', 'Family function at home.', 'Pending'),
(2, '2026-10-15', '2026-10-17', 'Medical checkup.',         'Approved');

INSERT INTO Laundry_Request (student_id, clothes_count, request_date, status) VALUES
(1, 5, '2026-10-10', 'Pending'),
(2, 3, '2026-10-11', 'Ready'),
(4, 4, '2026-10-11', 'In Progress');

INSERT INTO Visitor (student_id, visitor_name, relation, visit_date, time_in, time_out, status) VALUES
(1, 'Rahul Kumar',  'Brother', '2026-10-19', '14:15:00', NULL,       'Inside Hostel'),
(1, 'Meena Sharma', 'Mother',  '2026-08-20', '11:00:00', '13:30:00', 'Checked Out'),
(4, 'Sunita Rao',   'Mother',  '2026-09-01', '16:30:00', '18:00:00', 'Checked Out'),
(5, 'Vikram Iyer',  'Father',  '2026-09-02', '10:45:00', '12:15:00', 'Checked Out'),
(2, 'Aman Verma',   'Brother', '2026-10-19', '09:20:00', NULL,       'Inside Hostel');