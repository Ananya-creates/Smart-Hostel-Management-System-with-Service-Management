<?php
require '../config/db.php';
session_start();

// If already logged in, redirect to correct dashboard
if (isset($_SESSION['role'])) {
    header("Location: " . ($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'student/dashboard.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        if ($role === 'admin') {
            $stmt = $pdo->prepare("SELECT * FROM Admin WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && $password === $user['password']) { // Plain text check (we will hash later)
                $_SESSION['role'] = 'admin';
                $_SESSION['user_id'] = $user['admin_id'];
                $_SESSION['name'] = $user['username'];
                header("Location: admin/dashboard.php");
                exit;
            } else {
                $error = "Invalid admin credentials.";
            }
        } else {
            $stmt = $pdo->prepare("SELECT * FROM Student WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && $password === $user['password']) {
                $_SESSION['role'] = 'student';
                $_SESSION['user_id'] = $user['student_id'];
                $_SESSION['name'] = $user['name'];
                header("Location: student/dashboard.php");
                exit;
            } else {
                $error = "Invalid student credentials.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Hostel MS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-header">
            <h2>Welcome Back</h2>
            <p>Sign in to access your hostel portal</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Login As</label>
                <div class="role-toggle">
                    <input type="radio" id="role-student" name="role" value="student" checked>
                    <label for="role-student">Student</label>
                    <input type="radio" id="role-admin" name="role" value="admin">
                    <label for="role-admin">Admin</label>
                </div>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="you@hostel.com" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
        </form>

        <div class="auth-footer">
            New student? <a href="register.php">Register here</a>
        </div>
    </div>
</div>
</body>
</html>