<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $leave_id = (int)$_POST['leave_id'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE Leave_Application SET status=? WHERE leave_id=?");
    if ($stmt->execute([$status, $leave_id])) {
        $msg = "Leave application marked as $status.";
    }
}

$leaves = $pdo->query("
    SELECT l.*, s.name as student_name, s.course 
    FROM Leave_Application l
    JOIN Student s ON s.student_id = l.student_id
    ORDER BY l.status ASC, l.leave_id DESC
")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 450px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Leave Applications</h2>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Duration</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($leaves) > 0): ?>
                    <?php foreach ($leaves as $l): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($l['student_name']) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($l['course']) ?></div>
                        </td>
                        <td>
                            <div style="font-size: 13px;"><b>From:</b> <?= date('d M Y', strtotime($l['from_date'])) ?></div>
                            <div style="font-size: 13px;"><b>To:</b> <?= date('d M Y', strtotime($l['to_date'])) ?></div>
                        </td>
                        <td><?= htmlspecialchars($l['reason']) ?></td>
                        <td>
                            <?php 
                                $sClass = 'badge-warning';
                                if ($l['status'] == 'Approved') $sClass = 'badge-success';
                                if ($l['status'] == 'Rejected') $sClass = 'badge-danger';
                            ?>
                            <span class="badge <?= $sClass ?>"><?= $l['status'] ?></span>
                        </td>
                        <td>
                            <button class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--bg); border: 1px solid var(--border);" 
                                onclick='updateStatus(<?= json_encode($l) ?>)'>Review</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">No applications found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal-overlay" id="statusModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Review Leave</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="leave_id" id="leave_id">
            <div class="form-group">
                <label>Status</label>
                <select name="status" id="leave_status" class="form-control">
                    <option value="Pending">Pending</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('statusModal');
    function closeModal() { modal.classList.remove('active'); }
    function updateStatus(data) {
        document.getElementById('leave_id').value = data.leave_id;
        document.getElementById('leave_status').value = data.status;
        modal.classList.add('active');
    }
</script>

<?php require '../../includes/footer.php'; ?>