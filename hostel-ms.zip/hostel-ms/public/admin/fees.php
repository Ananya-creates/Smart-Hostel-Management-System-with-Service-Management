<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM Fee WHERE fee_id = ?");
    if ($stmt->execute([$id])) {
        $msg = "Fee record deleted.";
    }
}

// Handle Add Payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $amount = (float)$_POST['amount'];
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("INSERT INTO Fee (student_id, amount, due_date, payment_status) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$student_id, $amount, $due_date, $status])) {
        $msg = "Fee record added successfully.";
    } else {
        $error = "Failed to add fee record.";
    }
}

// Fetch all fee records with student names
$fees = $pdo->query("
    SELECT f.*, s.name as student_name, s.email 
    FROM Fee f
    JOIN Student s ON s.student_id = f.student_id
    ORDER BY f.fee_id DESC
")->fetchAll();

// Fetch all students for the dropdown
$students = $pdo->query("SELECT student_id, name FROM Student ORDER BY name ASC")->fetchAll();

// Calculate Totals
$totalCollected = $pdo->query("SELECT SUM(amount) FROM Fee WHERE payment_status = 'Paid'")->fetchColumn() ?: 0;
$totalPending = $pdo->query("SELECT SUM(amount) FROM Fee WHERE payment_status = 'Pending'")->fetchColumn() ?: 0;
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
    .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }
    .stat-card { background: #fff; padding: 20px; border-radius: var(--radius); border: 1px solid var(--border); border-left: 4px solid var(--success); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Fees Management</h2>
    <button class="btn btn-primary" onclick="openModal()">+ Record Payment</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;"><?= $error ?></div>
<?php endif; ?>

<div class="stats-grid">
    <div class="stat-card" style="border-left-color: var(--success);">
        <div style="font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Total Collected</div>
        <div style="font-size: 28px; font-weight: 800; margin-top: 8px; color: var(--success);">₹<?= number_format($totalCollected) ?></div>
    </div>
    <div class="stat-card" style="border-left-color: var(--danger);">
        <div style="font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Total Pending</div>
        <div style="font-size: 28px; font-weight: 800; margin-top: 8px; color: var(--danger);">₹<?= number_format($totalPending) ?></div>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>Amount</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($fees) > 0): ?>
                    <?php foreach ($fees as $f): ?>
                    <tr>
                        <td>#<?= $f['fee_id'] ?></td>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($f['student_name']) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($f['email']) ?></div>
                        </td>
                        <td><b>₹<?= number_format($f['amount']) ?></b></td>
                        <td><?= date('d M Y', strtotime($f['due_date'])) ?></td>
                        <td>
                            <?php 
                                $badgeClass = 'badge-warning';
                                if ($f['payment_status'] == 'Paid') $badgeClass = 'badge-success';
                                if ($f['payment_status'] == 'Partial') $badgeClass = 'badge-info';
                            ?>
                            <span class="badge <?= $badgeClass ?>"><?= $f['payment_status'] ?></span>
                        </td>
                        <td>
                            <a href="?delete=<?= $f['fee_id'] ?>" class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--danger-bg); color: var(--danger); border: 1px solid var(--danger);" onclick="return confirm('Delete this fee record?');">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align: center; padding: 30px; color: var(--text-muted);">No fee records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="feeModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Record Payment</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div class="form-group">
                <label>Student</label>
                <select name="student_id" class="form-control" required>
                    <option value="">-- Choose Student --</option>
                    <?php foreach ($students as $s): ?>
                        <option value="<?= $s['student_id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label>Amount (₹)</label>
                    <input type="number" name="amount" class="form-control" placeholder="e.g. 60000" required>
                </div>
                <div class="form-group">
                    <label>Payment Status</label>
                    <select name="status" class="form-control">
                        <option value="Paid">Paid</option>
                        <option value="Pending">Pending</option>
                        <option value="Partial">Partial</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Due Date</label>
                <input type="date" name="due_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Record</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('feeModal');
    function openModal() { modal.classList.add('active'); }
    function closeModal() { modal.classList.remove('active'); }
</script>

<?php require '../../includes/footer.php'; ?>