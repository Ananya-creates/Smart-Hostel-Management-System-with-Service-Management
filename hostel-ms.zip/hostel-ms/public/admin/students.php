<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM Student WHERE student_id = ?");
    if ($stmt->execute([$id])) {
        $msg = "Student deleted successfully.";
    }
}

// Handle Add / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $gender = $_POST['gender'];
    $course = trim($_POST['course']);
    $year = (int)$_POST['year'];
    $status = $_POST['status'];

    if (isset($_POST['student_id']) && !empty($_POST['student_id'])) {
        // Update
        $id = (int)$_POST['student_id'];
        $stmt = $pdo->prepare("UPDATE Student SET name=?, email=?, phone=?, gender=?, course=?, year=?, status=? WHERE student_id=?");
        if ($stmt->execute([$name, $email, $phone, $gender, $course, $year, $status, $id])) {
            $msg = "Student updated successfully.";
        } else {
            $error = "Failed to update student.";
        }
    } else {
        // Insert (default password: student123)
        $password = 'student123'; 
        $stmt = $pdo->prepare("INSERT INTO Student (name, email, phone, gender, course, year, password, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$name, $email, $phone, $gender, $course, $year, $password, $status])) {
            $msg = "Student added successfully. Default password: student123";
        } else {
            $error = "Failed to add student. Email might be duplicate.";
        }
    }
}

// Fetch all students with their room numbers
$students = $pdo->query("
    SELECT s.*, r.room_number 
    FROM Student s
    LEFT JOIN Room_Allocation a ON a.student_id = s.student_id
    LEFT JOIN Room r ON r.room_id = a.room_id
    ORDER BY s.student_id DESC
")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Students Management</h2>
    <button class="btn btn-primary" onclick="openModal()">+ Add Student</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;"><?= $error ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name & Email</th>
                    <th>Course & Year</th>
                    <th>Room</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $s): ?>
                <tr>
                    <td><b>#<?= $s['student_id'] ?></b></td>
                    <td>
                        <div style="font-weight: 600;"><?= htmlspecialchars($s['name']) ?></div>
                        <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($s['email']) ?></div>
                    </td>
                    <td>
                        <div><?= htmlspecialchars($s['course']) ?></div>
                        <div style="font-size: 12px; color: var(--text-muted);">Year <?= $s['year'] ?></div>
                    </td>
                    <td>
                        <?= $s['room_number'] ? '<b>' . htmlspecialchars($s['room_number']) . '</b>' : '<span style="color:var(--text-muted)">Not Allocated</span>' ?>
                    </td>
                    <td>
                        <span class="badge <?= $s['status'] == 'Active' ? 'badge-success' : 'badge-warning' ?>">
                            <?= $s['status'] ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--bg); border: 1px solid var(--border);" 
                            onclick='editStudent(<?= json_encode($s) ?>)'>Edit</button>
                        <a href="?delete=<?= $s['student_id'] ?>" class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--danger-bg); color: var(--danger); border: 1px solid var(--danger);" onclick="return confirm('Are you sure you want to delete this student?');">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="studentModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add New Student</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="student_id" id="student_id">
            
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" id="phone" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Gender</label>
                    <select name="gender" id="gender" class="form-control">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label>Course</label>
                    <input type="text" name="course" id="course" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Year</label>
                    <select name="year" id="year" class="form-control">
                        <option value="1">1st Year</option>
                        <option value="2">2nd Year</option>
                        <option value="3">3rd Year</option>
                        <option value="4">4th Year</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status" id="status" class="form-control">
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                </select>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Student</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('studentModal');
    const form = document.querySelector('form');

    function openModal() {
        document.getElementById('modalTitle').innerText = 'Add New Student';
        form.reset();
        document.getElementById('student_id').value = '';
        modal.classList.add('active');
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    function editStudent(data) {
        document.getElementById('modalTitle').innerText = 'Edit Student';
        document.getElementById('student_id').value = data.student_id;
        document.getElementById('name').value = data.name;
        document.getElementById('email').value = data.email;
        document.getElementById('phone').value = data.phone;
        document.getElementById('gender').value = data.gender;
        document.getElementById('course').value = data.course;
        document.getElementById('year').value = data.year;
        document.getElementById('status').value = data.status;
        modal.classList.add('active');
    }
</script>

<?php require '../../includes/footer.php'; ?>