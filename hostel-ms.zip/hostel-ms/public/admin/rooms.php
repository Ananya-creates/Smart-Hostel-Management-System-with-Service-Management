<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM Room WHERE room_id = ?");
    if ($stmt->execute([$id])) {
        $msg = "Room deleted successfully.";
    }
}

// Handle Add / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_number = trim($_POST['room_number']);
    $block = trim($_POST['block']);
    $floor = trim($_POST['floor']);
    $capacity = (int)$_POST['capacity'];
    $status = $_POST['status'];
    $admin_id = $_SESSION['user_id'];

    if (isset($_POST['room_id']) && !empty($_POST['room_id'])) {
        // Update
        $id = (int)$_POST['room_id'];
        $stmt = $pdo->prepare("UPDATE Room SET room_number=?, block=?, floor=?, capacity=?, status=? WHERE room_id=?");
        if ($stmt->execute([$room_number, $block, $floor, $capacity, $status, $id])) {
            $msg = "Room updated successfully.";
        } else {
            $error = "Failed to update room. Room number might be duplicate.";
        }
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO Room (admin_id, room_number, block, floor, capacity, status) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$admin_id, $room_number, $block, $floor, $capacity, $status])) {
            $msg = "Room added successfully.";
        } else {
            $error = "Failed to add room. Room number might be duplicate.";
        }
    }
}

// Fetch all rooms
$rooms = $pdo->query("SELECT * FROM Room ORDER BY room_number ASC")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Rooms Management</h2>
    <button class="btn btn-primary" onclick="openModal()">+ Add Room</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;"><?= $error ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Room No.</th>
                    <th>Block & Floor</th>
                    <th>Capacity</th>
                    <th>Occupied</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rooms as $r): ?>
                <tr>
                    <td><b><?= htmlspecialchars($r['room_number']) ?></b></td>
                    <td>
                        <div>Block <?= htmlspecialchars($r['block']) ?></div>
                        <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($r['floor']) ?></div>
                    </td>
                    <td><?= $r['capacity'] ?> Beds</td>
                    <td>
                        <b style="color: <?= $r['occupied'] >= $r['capacity'] ? 'var(--danger)' : 'var(--success)' ?>;">
                            <?= $r['occupied'] ?> / <?= $r['capacity'] ?>
                        </b>
                    </td>
                    <td>
                        <?php 
                            $badgeClass = 'badge-success';
                            if ($r['status'] == 'Full') $badgeClass = 'badge-danger';
                            if ($r['status'] == 'Vacant') $badgeClass = 'badge-info';
                            if ($r['status'] == 'Available') $badgeClass = 'badge-warning';
                        ?>
                        <span class="badge <?= $badgeClass ?>"><?= $r['status'] ?></span>
                    </td>
                    <td>
                        <button class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--bg); border: 1px solid var(--border);" 
                            onclick='editRoom(<?= json_encode($r) ?>)'>Edit</button>
                        <a href="?delete=<?= $r['room_id'] ?>" class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--danger-bg); color: var(--danger); border: 1px solid var(--danger);" onclick="return confirm('Are you sure you want to delete this room? This will also remove any student allocations in this room!');">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="roomModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add New Room</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="room_id" id="room_id">
            
            <div class="form-group">
                <label>Room Number</label>
                <input type="text" name="room_number" id="room_number" class="form-control" placeholder="e.g. A-104" required>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label>Block</label>
                    <input type="text" name="block" id="block" class="form-control" placeholder="e.g. A" required>
                </div>
                <div class="form-group">
                    <label>Floor</label>
                    <input type="text" name="floor" id="floor" class="form-control" placeholder="e.g. 1st Floor" required>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label>Capacity (Beds)</label>
                    <input type="number" name="capacity" id="capacity" class="form-control" min="1" max="6" required>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="status" class="form-control">
                        <option value="Vacant">Vacant</option>
                        <option value="Available">Available</option>
                        <option value="Full">Full</option>
                        <option value="Maintenance">Under Maintenance</option>
                    </select>
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Room</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('roomModal');
    const form = document.querySelector('form');

    function openModal() {
        document.getElementById('modalTitle').innerText = 'Add New Room';
        form.reset();
        document.getElementById('room_id').value = '';
        modal.classList.add('active');
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    function editRoom(data) {
        document.getElementById('modalTitle').innerText = 'Edit Room ' + data.room_number;
        document.getElementById('room_id').value = data.room_id;
        document.getElementById('room_number').value = data.room_number;
        document.getElementById('block').value = data.block;
        document.getElementById('floor').value = data.floor;
        document.getElementById('capacity').value = data.capacity;
        document.getElementById('status').value = data.status;
        modal.classList.add('active');
    }
</script>

<?php require '../../includes/footer.php'; ?>