<?php
require '../../config/db.php';
require '../../includes/header.php';

// Fetch stats using SQL
$totalStudents = $pdo->query("SELECT COUNT(*) FROM Student")->fetchColumn();
$totalRooms = $pdo->query("SELECT COUNT(*) FROM Room")->fetchColumn();
$pendingMaint = $pdo->query("SELECT COUNT(*) FROM Maintenance_Request WHERE status = 'Pending'")->fetchColumn();
$feesCollected = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM Fee WHERE payment_status = 'Paid'")->fetchColumn();

// Calculate Occupancy
$roomStats = $pdo->query("SELECT SUM(occupied) as occ, SUM(capacity) as cap FROM Room")->fetch();
$occupancy = $roomStats['cap'] > 0 ? round(($roomStats['occ'] / $roomStats['cap']) * 100) : 0;

// Fetch recent notices
$notices = $pdo->query("SELECT * FROM Notice ORDER BY publish_date DESC LIMIT 3")->fetchAll();
?>

<style>
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 32px; }
    .stat-card { background: #fff; padding: 24px; border-radius: var(--radius); border: 1px solid var(--border); border-left: 4px solid var(--primary); }
    .stat-title { font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase; }
    .stat-value { font-size: 28px; font-weight: 800; margin-top: 8px; color: var(--text); }
    
    .notice-item { padding: 16px 0; border-bottom: 1px solid var(--border); }
    .notice-item:last-child { border-bottom: none; padding-bottom: 0; }
    .notice-title { font-weight: 700; font-size: 14px; color: var(--text); }
    .notice-date { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
</style>

<h2 style="margin-bottom: 24px; font-size: 24px;">Overview</h2>

<div class="stats-grid">
    <div class="stat-card" style="border-left-color: var(--primary);">
        <div class="stat-title">Total Students</div>
        <div class="stat-value"><?= $totalStudents ?></div>
    </div>
    <div class="stat-card" style="border-left-color: var(--info);">
        <div class="stat-title">Occupancy Rate</div>
        <div class="stat-value"><?= $occupancy ?>%</div>
    </div>
    <div class="stat-card" style="border-left-color: var(--success);">
        <div class="stat-title">Fees Collected</div>
        <div class="stat-value">₹<?= number_format($feesCollected) ?></div>
    </div>
    <div class="stat-card" style="border-left-color: var(--warning);">
        <div class="stat-title">Pending Maintenance</div>
        <div class="stat-value"><?= $pendingMaint ?></div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Recent Notices</h3>
        <a href="notices.php" class="btn btn-primary" style="padding: 8px 16px; font-size: 13px;">Manage Notices</a>
    </div>
    <div class="card-body">
        <?php if (count($notices) > 0): ?>
            <?php foreach ($notices as $n): ?>
                <div class="notice-item">
                    <div class="notice-title"><?= htmlspecialchars($n['title']) ?></div>
                    <div class="notice-date">Published: <?= date('d M Y', strtotime($n['publish_date'])) ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="color: var(--text-muted);">No notices published yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>