<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';
$error = '';

// Handle Deallocation (Delete)
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // Get room_id before deleting
    $stmt = $pdo->prepare("SELECT room_id FROM Room_Allocation WHERE allocation_id = ?");
    $stmt->execute([$id]);
    $alloc = $stmt->fetch();

    if ($alloc) {
        try {
            $pdo->beginTransaction();
            
            // 1. Delete allocation
            $pdo->prepare("DELETE FROM Room_Allocation WHERE allocation_id = ?")->execute([$id]);
            
            // 2. Decrease room occupancy
            $pdo->prepare("UPDATE Room SET occupied = GREATEST(0, occupied - 1) WHERE room_id = ?")->execute([$alloc['room_id']]);
            $pdo->prepare("UPDATE Room SET status = 'Available' WHERE room_id = ? AND occupied < capacity")->execute([$alloc['room_id']]);
            
            $pdo->commit();
            $msg = "Allocation removed successfully.";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Failed to remove allocation.";
        }
    }
}

// Handle New Allocation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['allocate'])) {
    $student_id = (int)$_POST['student_id'];
    $room_id = (int)$_POST['room_id'];

    // Check if student already has a room
    $stmt = $pdo->prepare("SELECT * FROM Room_Allocation WHERE student_id = ?");
    $stmt->execute([$student_id]);
    if ($stmt->fetch()) {
        $error = "This student is already allocated to a room.";
    } else {
        // Check if room is full
        $stmt = $pdo->prepare("SELECT capacity, occupied FROM Room WHERE room_id = ?");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();

        if ($room['occupied'] >= $room['capacity']) {
            $error = "This room is already full.";
        } else {
            try {
                $pdo->beginTransaction();

                // 1. Insert Allocation
                $stmt = $pdo->prepare("INSERT INTO Room_Allocation (student_id, room_id, allocation_date) VALUES (?, ?, CURDATE())");
                $stmt->execute([$student_id, $room_id]);

                // 2. Update Room Occupancy
                $newOccupied = $room['occupied'] + 1;
                $newStatus = ($newOccupied >= $room['capacity']) ? 'Full' : 'Available';
                
                $stmt = $pdo->prepare("UPDATE Room SET occupied = ?, status = ? WHERE room_id = ?");
                $stmt->execute([$newOccupied, $newStatus, $room_id]);

                $pdo->commit();
                $msg = "Room allocated successfully.";
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Failed to allocate room.";
            }
        }
    }
}

// Fetch all active allocations
$allocations = $pdo->query("
    SELECT a.allocation_id, a.allocation_date, s.name as student_name, s.student_id, r.room_number, r.block
    FROM Room_Allocation a
    JOIN Student s ON s.student_id = a.student_id
    JOIN Room r ON r.room_id = a.room_id
    ORDER BY a.allocation_date DESC
")->fetchAll();

// Fetch students WITHOUT a room for the dropdown
$unallocatedStudents = $pdo->query("
    SELECT s.student_id, s.name 
    FROM Student s
    LEFT JOIN Room_Allocation a ON a.student_id = s.student_id
    WHERE a.allocation_id IS NULL
")->fetchAll();

// Fetch rooms with available space for the dropdown
$availableRooms = $pdo->query("
    SELECT room_id, room_number, block, capacity, occupied 
    FROM Room 
    WHERE occupied < capacity 
    AND status != 'Maintenance'
")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Room Allocations</h2>
    <button class="btn btn-primary" onclick="openModal()" <?= (count($unallocatedStudents) == 0 || count($availableRooms) == 0) ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : '' ?>>+ New Allocation</button>
</div>

<?php if (count($unallocatedStudents) == 0 && count($availableRooms) > 0): ?>
    <div class="alert alert-info" style="margin-bottom: 20px;">All students currently have a room allocated.</div>
<?php elseif (count($availableRooms) == 0): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;">All rooms are full! Add more rooms to allocate students.</div>
<?php endif; ?>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;"><?= $error ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Alloc ID</th>
                    <th>Student</th>
                    <th>Room</th>
                    <th>Allocation Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($allocations) > 0): ?>
                    <?php foreach ($allocations as $a): ?>
                    <tr>
                        <td><b>#<?= $a['allocation_id'] ?></b></td>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($a['student_name']) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);">Student ID: <?= $a['student_id'] ?></div>
                        </td>
                        <td>
                            <b><?= htmlspecialchars($a['room_number']) ?></b>
                            <div style="font-size: 12px; color: var(--text-muted);">Block <?= htmlspecialchars($a['block']) ?></div>
                        </td>
                        <td><?= date('d M Y', strtotime($a['allocation_date'])) ?></td>
                        <td>
                            <a href="?delete=<?= $a['allocation_id'] ?>" class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--danger-bg); color: var(--danger); border: 1px solid var(--danger);" onclick="return confirm('Remove this student from the room?');">Deallocate</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">No rooms allocated yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="allocModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Allocate Room</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="allocate" value="1">
            
            <div class="form-group">
                <label>Select Student</label>
                <select name="student_id" class="form-control" required>
                    <option value="">-- Choose Student --</option>
                    <?php foreach ($unallocatedStudents as $s): ?>
                        <option value="<?= $s['student_id'] ?>"><?= htmlspecialchars($s['name']) ?> (ID: <?= $s['student_id'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Select Room</label>
                <select name="room_id" class="form-control" required>
                    <option value="">-- Choose Room --</option>
                    <?php foreach ($availableRooms as $r): ?>
                        <option value="<?= $r['room_id'] ?>">
                            <?= htmlspecialchars($r['room_number']) ?> (Block <?= htmlspecialchars($r['block']) ?>) - <?= $r['occupied'] ?>/<?= $r['capacity'] ?> Beds Filled
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Allocate</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('allocModal');

    function openModal() {
        modal.classList.add('active');
    }

    function closeModal() {
        modal.classList.remove('active');
    }
</script>

<?php require '../../includes/footer.php'; ?>