<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $menu_id = (int)$_POST['menu_id'];
    $breakfast = trim($_POST['breakfast']);
    $lunch = trim($_POST['lunch']);
    $snacks = trim($_POST['snacks']);
    $dinner = trim($_POST['dinner']);

    $stmt = $pdo->prepare("UPDATE Mess_Menu SET breakfast=?, lunch=?, snacks=?, dinner=? WHERE menu_id=?");
    if ($stmt->execute([$breakfast, $lunch, $snacks, $dinner, $menu_id])) {
        $msg = "Menu updated successfully.";
    }
}

// Fetch menu (ordered by day of week using FIELD function)
$menu = $pdo->query("
    SELECT * FROM Mess_Menu 
    ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Mess Menu Management</h2>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Day</th>
                    <th>Breakfast</th>
                    <th>Lunch</th>
                    <th>Snacks</th>
                    <th>Dinner</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($menu as $m): ?>
                <tr>
                    <td><b><?= htmlspecialchars($m['day']) ?></b></td>
                    <td><?= htmlspecialchars($m['breakfast']) ?></td>
                    <td><?= htmlspecialchars($m['lunch']) ?></td>
                    <td><?= htmlspecialchars($m['snacks']) ?></td>
                    <td><?= htmlspecialchars($m['dinner']) ?></td>
                    <td>
                        <button class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--bg); border: 1px solid var(--border);" 
                            onclick='editMenu(<?= json_encode($m) ?>)'>Edit</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="menuModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Edit Menu</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="menu_id" id="menu_id">
            
            <div class="form-group">
                <label>Breakfast</label>
                <input type="text" name="breakfast" id="breakfast" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Lunch</label>
                <input type="text" name="lunch" id="lunch" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Snacks</label>
                <input type="text" name="snacks" id="snacks" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Dinner</label>
                <input type="text" name="dinner" id="dinner" class="form-control" required>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('menuModal');

    function closeModal() { modal.classList.remove('active'); }

    function editMenu(data) {
        document.getElementById('modalTitle').innerText = 'Edit ' + data.day + ' Menu';
        document.getElementById('menu_id').value = data.menu_id;
        document.getElementById('breakfast').value = data.breakfast;
        document.getElementById('lunch').value = data.lunch;
        document.getElementById('snacks').value = data.snacks;
        document.getElementById('dinner').value = data.dinner;
        modal.classList.add('active');
    }
</script>

<?php require '../../includes/footer.php'; ?>