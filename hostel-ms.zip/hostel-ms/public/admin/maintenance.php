<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';

// Handle Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = (int)$_POST['request_id'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE Maintenance_Request SET status=? WHERE request_id=?");
    if ($stmt->execute([$status, $request_id])) {
        $msg = "Request status updated to $status.";
    }
}

// Fetch all requests with student details
$requests = $pdo->query("
    SELECT m.*, s.name as student_name, r.room_number
    FROM Maintenance_Request m
    JOIN Student s ON s.student_id = m.student_id
    LEFT JOIN Room_Allocation a ON a.student_id = s.student_id
    LEFT JOIN Room r ON r.room_id = a.room_id
    ORDER BY m.status ASC, m.request_id DESC
")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 450px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Maintenance Requests</h2>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Student & Room</th>
                    <th>Issue</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($requests) > 0): ?>
                    <?php foreach ($requests as $r): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($r['student_name']) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);">
                                <?= $r['room_number'] ? 'Room ' . htmlspecialchars($r['room_number']) : 'No Room' ?>
                            </div>
                        </td>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($r['issue_type']) ?></div>
                            <div style="font-size: 13px; color: var(--text-muted); margin-top: 4px; max-width: 300px;"><?= htmlspecialchars($r['description']) ?></div>
                        </td>
                        <td>
                            <?php 
                                $pClass = 'badge-info';
                                if ($r['priority'] == 'High') $pClass = 'badge-danger';
                                if ($r['priority'] == 'Medium') $pClass = 'badge-warning';
                            ?>
                            <span class="badge <?= $pClass ?>"><?= $r['priority'] ?></span>
                        </td>
                        <td>
                            <?php 
                                $sClass = 'badge-warning';
                                if ($r['status'] == 'Resolved') $sClass = 'badge-success';
                                if ($r['status'] == 'In Progress') $sClass = 'badge-info';
                            ?>
                            <span class="badge <?= $sClass ?>"><?= $r['status'] ?></span>
                        </td>
                        <td>
                            <button class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--bg); border: 1px solid var(--border);" 
                                onclick='updateStatus(<?= json_encode($r) ?>)'>Update</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">No requests found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Update Modal -->
<div class="modal-overlay" id="statusModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Update Status</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="request_id" id="req_id">
            
            <div class="form-group">
                <label>Status</label>
                <select name="status" id="req_status" class="form-control">
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                </select>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('statusModal');
    function closeModal() { modal.classList.remove('active'); }

    function updateStatus(data) {
        document.getElementById('req_id').value = data.request_id;
        document.getElementById('req_status').value = data.status;
        modal.classList.add('active');
    }
</script>

<?php require '../../includes/footer.php'; ?>