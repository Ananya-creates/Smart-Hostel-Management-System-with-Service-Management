<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';

// Handle Check-Out
if (isset($_GET['checkout'])) {
    $id = (int)$_GET['checkout'];
    $stmt = $pdo->prepare("UPDATE Visitor SET status='Checked Out', time_out=CURTIME() WHERE visitor_id=?");
    if ($stmt->execute([$id])) {
        $msg = "Visitor checked out successfully.";
    }
}

// Handle Add Visitor
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $visitor_name = trim($_POST['visitor_name']);
    $relation = $_POST['relation'];

    $stmt = $pdo->prepare("INSERT INTO Visitor (student_id, visitor_name, relation, visit_date, time_in, status) VALUES (?, ?, ?, CURDATE(), CURTIME(), 'Inside Hostel')");
    if ($stmt->execute([$student_id, $visitor_name, $relation])) {
        $msg = "Visitor entry recorded.";
    }
}

// Fetch all visitors
$visitors = $pdo->query("
    SELECT v.*, s.name as student_name, r.room_number
    FROM Visitor v
    JOIN Student s ON s.student_id = v.student_id
    LEFT JOIN Room_Allocation a ON a.student_id = s.student_id
    LEFT JOIN Room r ON r.room_id = a.room_id
    ORDER BY v.status ASC, v.visit_date DESC, v.time_in DESC
")->fetchAll();

// Fetch students for dropdown
$students = $pdo->query("SELECT student_id, name FROM Student ORDER BY name ASC")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Visitor Log</h2>
    <button class="btn btn-primary" onclick="openModal()">+ Log Visitor</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Visitor</th>
                    <th>Meeting Student</th>
                    <th>Date & Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($visitors) > 0): ?>
                    <?php foreach ($visitors as $v): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($v['visitor_name']) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($v['relation']) ?></div>
                        </td>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($v['student_name']) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);">
                                <?= $v['room_number'] ? 'Room ' . htmlspecialchars($v['room_number']) : 'No Room' ?>
                            </div>
                        </td>
                        <td>
                            <div><?= date('d M Y', strtotime($v['visit_date'])) ?></div>
                            <div style="font-size: 12px; color: var(--text-muted);">
                                In: <?= date('h:i A', strtotime($v['time_in'])) ?>
                                <?= $v['time_out'] ? ' | Out: ' . date('h:i A', strtotime($v['time_out'])) : '' ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge <?= $v['status'] == 'Inside Hostel' ? 'badge-info' : 'badge-success' ?>">
                                <?= $v['status'] ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($v['status'] == 'Inside Hostel'): ?>
                                <a href="?checkout=<?= $v['visitor_id'] ?>" class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--warning-bg); color: var(--warning); border: 1px solid var(--warning);">Check Out</a>
                            <?php else: ?>
                                <span style="font-size: 12px; color: var(--text-muted);">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">No visitors logged yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal-overlay" id="visitorModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Log New Visitor</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div class="form-group">
                <label>Visitor Name</label>
                <input type="text" name="visitor_name" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Relationship</label>
                <select name="relation" class="form-control">
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Brother">Brother</option>
                    <option value="Sister">Sister</option>
                    <option value="Friend">Friend</option>
                    <option value="Guardian">Guardian</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label>Meeting Student</label>
                <select name="student_id" class="form-control" required>
                    <option value="">-- Choose Student --</option>
                    <?php foreach ($students as $s): ?>
                        <option value="<?= $s['student_id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Log Visitor</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('visitorModal');
    function openModal() { modal.classList.add('active'); }
    function closeModal() { modal.classList.remove('active'); }
</script>

<?php require '../../includes/footer.php'; ?>