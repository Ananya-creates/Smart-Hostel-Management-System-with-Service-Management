<?php
require '../../config/db.php';
require '../../includes/header.php';

$msg = '';
$error = '';
$admin_id = $_SESSION['user_id'];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM Notice WHERE notice_id = ?");
    if ($stmt->execute([$id])) {
        $msg = "Notice deleted successfully.";
    }
}

// Handle Add
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $desc = trim($_POST['description']);
    $date = $_POST['publish_date'];

    $stmt = $pdo->prepare("INSERT INTO Notice (admin_id, title, description, publish_date) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$admin_id, $title, $desc, $date])) {
        $msg = "Notice published successfully.";
    } else {
        $error = "Failed to publish notice.";
    }
}

// Fetch all notices
$notices = $pdo->query("SELECT * FROM Notice ORDER BY publish_date DESC")->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <h2 style="font-size: 24px; margin: 0;">Notice Board</h2>
    <button class="btn btn-primary" onclick="openModal()">+ Publish Notice</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;"><?= $error ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Title & Description</th>
                    <th>Published Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($notices) > 0): ?>
                    <?php foreach ($notices as $n): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 700; font-size: 15px; margin-bottom: 4px;"><?= htmlspecialchars($n['title']) ?></div>
                            <div style="font-size: 13px; color: var(--text-muted); max-width: 500px;"><?= nl2br(htmlspecialchars($n['description'])) ?></div>
                        </td>
                        <td><?= date('d M Y', strtotime($n['publish_date'])) ?></td>
                        <td>
                            <a href="?delete=<?= $n['notice_id'] ?>" class="btn" style="padding: 6px 12px; font-size: 12px; background: var(--danger-bg); color: var(--danger); border: 1px solid var(--danger);" onclick="return confirm('Delete this notice?');">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" style="text-align: center; padding: 30px; color: var(--text-muted);">No notices published yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="noticeModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Publish Notice</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div class="form-group">
                <label>Notice Title</label>
                <input type="text" name="title" class="form-control" placeholder="e.g. Diwali Holidays" required>
            </div>
            
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="4" placeholder="Write the details here..." required></textarea>
            </div>

            <div class="form-group">
                <label>Publish Date</label>
                <input type="date" name="publish_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Publish</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('noticeModal');
    function openModal() { modal.classList.add('active'); }
    function closeModal() { modal.classList.remove('active'); }
</script>

<?php require '../../includes/footer.php'; ?>