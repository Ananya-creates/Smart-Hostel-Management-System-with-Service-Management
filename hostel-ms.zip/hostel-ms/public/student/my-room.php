<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];

// Fetch my room details
$stmt = $pdo->prepare("
    SELECT r.room_number, r.block, r.floor, r.capacity, r.occupied, a.allocation_date 
    FROM Room_Allocation a
    JOIN Room r ON r.room_id = a.room_id
    WHERE a.student_id = ?
");
$stmt->execute([$student_id]);
$room = $stmt->fetch();

// Fetch my roommates (if I have a room)
$roommates = [];
if ($room) {
    $stmt = $pdo->prepare("
        SELECT s.name, s.course, s.phone 
        FROM Room_Allocation a
        JOIN Student s ON s.student_id = a.student_id
        WHERE a.room_id = (SELECT room_id FROM Room_Allocation WHERE student_id = ?) 
        AND a.student_id != ?
    ");
    $stmt->execute([$student_id, $student_id]);
    $roommates = $stmt->fetchAll();
}
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 24px; margin: 0;">My Room</h2>
    <p style="color: var(--text-muted); margin-top: 4px;">Your room details and roommates.</p>
</div>

<?php if (!$room): ?>
    <div class="card">
        <div class="card-body" style="text-align: center; padding: 40px;">
            <div style="font-size: 48px; margin-bottom: 16px;">🏠</div>
            <h3 style="font-size: 18px; margin-bottom: 8px;">No Room Allocated Yet</h3>
            <p style="color: var(--text-muted);">Please contact the hostel administration to get a room assigned.</p>
        </div>
    </div>
<?php else: ?>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
        <!-- Room Details -->
        <div class="card" style="margin: 0; border-left: 4px solid var(--primary);">
            <div class="card-header">
                <h3>Room Details</h3>
            </div>
            <div class="card-body">
                <div style="text-align: center; padding: 24px; background: linear-gradient(135deg, var(--tertiary), var(--secondary)); color: var(--primary-dark); border-radius: var(--radius); margin-bottom: 24px; box-shadow: var(--shadow-sm);">
    <div style="font-size: 48px; font-weight: 800;"><?= htmlspecialchars($room['room_number']) ?></div>
    <div style="font-weight: 600; opacity: 0.9;">Block <?= htmlspecialchars($room['block']) ?></div>
</div>
                
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <li style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border);">
                        <span style="color: var(--text-muted);">Floor</span>
                        <b><?= htmlspecialchars($room['floor']) ?></b>
                    </li>
                    <li style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border);">
                        <span style="color: var(--text-muted);">Occupancy</span>
                        <b><?= $room['occupied'] ?> / <?= $room['capacity'] ?> Beds</b>
                    </li>
                    <li style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border);">
                        <span style="color: var(--text-muted);">Allocated On</span>
                        <b><?= date('d M Y', strtotime($room['allocation_date'])) ?></b>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Roommates -->
        <div class="card" style="margin: 0;">
            <div class="card-header">
                <h3>My Roommates</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($roommates) > 0): ?>
                            <?php foreach ($roommates as $rm): ?>
                            <tr>
                                <td><b><?= htmlspecialchars($rm['name']) ?></b></td>
                                <td><?= htmlspecialchars($rm['course']) ?></td>
                                <td><?= htmlspecialchars($rm['phone']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="3" style="text-align: center; padding: 20px; color: var(--text-muted);">You have no roommates currently.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require '../../includes/footer.php'; ?>