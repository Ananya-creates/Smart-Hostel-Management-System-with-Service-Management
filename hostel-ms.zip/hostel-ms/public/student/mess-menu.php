<?php
require '../../config/db.php';
require '../../includes/student_header.php';

// Fetch menu, ordered properly
$menu = $pdo->query("
    SELECT * FROM Mess_Menu 
    ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
")->fetchAll();

$today = date('l'); // Gets current day (e.g., "Monday")
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 24px; margin: 0;">Weekly Mess Menu</h2>
    <p style="color: var(--text-muted); margin-top: 4px;">Check what's cooking in the hostel mess today!</p>
</div>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Day</th>
                    <th>Breakfast</th>
                    <th>Lunch</th>
                    <th>Snacks</th>
                    <th>Dinner</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($menu as $m): ?>
                <tr style="<?= $m['day'] === $today ? 'background: var(--primary-light); border-left: 4px solid var(--primary);' : '' ?>">
                    <td>
                        <b><?= htmlspecialchars($m['day']) ?></b>
                        <?php if ($m['day'] === $today): ?>
                            <div style="font-size: 10px; color: var(--primary); font-weight: 800; margin-top: 4px; text-transform: uppercase;">Today</div>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($m['breakfast']) ?></td>
                    <td><?= htmlspecialchars($m['lunch']) ?></td>
                    <td><?= htmlspecialchars($m['snacks']) ?></td>
                    <td><?= htmlspecialchars($m['dinner']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>