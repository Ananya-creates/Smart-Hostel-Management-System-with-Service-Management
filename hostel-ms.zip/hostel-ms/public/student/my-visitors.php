<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];

// Fetch my visitors
$stmt = $pdo->prepare("SELECT * FROM Visitor WHERE student_id = ? ORDER BY visit_date DESC, time_in DESC");
$stmt->execute([$student_id]);
$visitors = $stmt->fetchAll();
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 24px; margin: 0;">My Visitors</h2>
    <p style="color: var(--text-muted); margin-top: 4px;">History of guests who have visited you.</p>
</div>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Visitor Name</th>
                    <th>Relationship</th>
                    <th>Date</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($visitors) > 0): ?>
                    <?php foreach ($visitors as $v): ?>
                    <tr>
                        <td><b><?= htmlspecialchars($v['visitor_name']) ?></b></td>
                        <td><?= htmlspecialchars($v['relation']) ?></td>
                        <td><?= date('d M Y', strtotime($v['visit_date'])) ?></td>
                        <td><?= date('h:i A', strtotime($v['time_in'])) ?></td>
                        <td><?= $v['time_out'] ? date('h:i A', strtotime($v['time_out'])) : '-' ?></td>
                        <td>
                            <span class="badge <?= $v['status'] == 'Inside Hostel' ? 'badge-info' : 'badge-success' ?>">
                                <?= $v['status'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align: center; padding: 30px; color: var(--text-muted);">No visitors recorded yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>