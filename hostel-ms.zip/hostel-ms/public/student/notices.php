<?php
require '../../config/db.php';
require '../../includes/student_header.php';

// Fetch all notices
$notices = $pdo->query("SELECT * FROM Notice ORDER BY publish_date DESC")->fetchAll();
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 24px; margin: 0;">Notice Board</h2>
    <p style="color: var(--text-muted); margin-top: 4px;">Important announcements from the hostel administration.</p>
</div>

<div class="card">
    <div class="card-body">
        <?php if (count($notices) > 0): ?>
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <?php foreach ($notices as $n): ?>
                <div style="border-left: 4px solid var(--primary); background: var(--bg); padding: 20px; border-radius: 0 var(--radius) var(--radius) 0;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
                        <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: var(--text);"><?= htmlspecialchars($n['title']) ?></h3>
                        <span style="font-size: 12px; color: var(--text-muted); background: #fff; padding: 4px 8px; border-radius: 4px; border: 1px solid var(--border);">
                            <?= date('d M Y', strtotime($n['publish_date'])) ?>
                        </span>
                    </div>
                    <p style="margin: 0; font-size: 14px; color: var(--text-muted); line-height: 1.6;">
                        <?= nl2br(htmlspecialchars($n['description'])) ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="text-align: center; padding: 40px;">
                <div style="font-size: 40px; margin-bottom: 16px;">📭</div>
                <h3 style="font-size: 18px; margin-bottom: 8px;">No Notices Yet</h3>
                <p style="color: var(--text-muted);">Check back later for announcements.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>