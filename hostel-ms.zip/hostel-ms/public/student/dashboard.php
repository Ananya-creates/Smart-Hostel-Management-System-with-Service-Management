<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];

// Fetch my room
$stmt = $pdo->prepare("SELECT r.room_number, r.block FROM Room_Allocation a JOIN Room r ON r.room_id = a.room_id WHERE a.student_id = ?");
$stmt->execute([$student_id]);
$myRoom = $stmt->fetch();

// Fetch my fee status
$stmt = $pdo->prepare("SELECT SUM(amount) FROM Fee WHERE student_id = ? AND payment_status = 'Paid'");
$stmt->execute([$student_id]);
$paidFees = $stmt->fetchColumn() ?: 0;

// Fetch recent notices
$notices = $pdo->query("SELECT * FROM Notice ORDER BY publish_date DESC LIMIT 3")->fetchAll();
?>

<h2 style="margin-bottom: 24px; font-size: 24px;">Welcome, <?= htmlspecialchars(explode(' ', $_SESSION['name'])[0]) ?>!</h2>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
    <div class="card" style="margin: 0; border-left: 4px solid var(--info);">
        <div class="card-body">
            <div style="font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">My Room</div>
            <div style="font-size: 28px; font-weight: 800; margin-top: 8px;">
                <?= $myRoom ? htmlspecialchars($myRoom['room_number']) : 'Not Allocated' ?>
            </div>
            <?php if ($myRoom): ?>
                <div style="font-size: 14px; color: var(--text-muted); margin-top: 4px;">Block <?= htmlspecialchars($myRoom['block']) ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card" style="margin: 0; border-left: 4px solid var(--success);">
        <div class="card-body">
            <div style="font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Fees Paid</div>
            <div style="font-size: 28px; font-weight: 800; margin-top: 8px; color: var(--success);">₹<?= number_format($paidFees) ?></div>
            <div style="font-size: 14px; color: var(--text-muted); margin-top: 4px;">Out of ₹60,000</div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Recent Notices</h3>
        <a href="notices.php" class="btn btn-primary" style="padding: 8px 16px; font-size: 13px;">View All</a>
    </div>
    <div class="card-body">
        <?php if (count($notices) > 0): ?>
            <?php foreach ($notices as $n): ?>
                <div style="padding: 16px 0; border-bottom: 1px solid var(--border);">
                    <div style="font-weight: 700; font-size: 14px; color: var(--text);"><?= htmlspecialchars($n['title']) ?></div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Published: <?= date('d M Y', strtotime($n['publish_date'])) ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="color: var(--text-muted);">No notices published yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>