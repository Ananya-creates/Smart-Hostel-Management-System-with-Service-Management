<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];
$msg = '';
$error = '';

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $course = trim($_POST['course']);
    $year = (int)$_POST['year'];

    // Basic validation
    if (empty($name) || empty($phone)) {
        $error = "Name and Phone cannot be empty.";
    } else {
        $stmt = $pdo->prepare("UPDATE Student SET name=?, phone=?, course=?, year=? WHERE student_id=?");
        if ($stmt->execute([$name, $phone, $course, $year, $student_id])) {
            $_SESSION['name'] = $name; // Update session name so the topbar reflects changes instantly
            $msg = "Profile updated successfully.";
        } else {
            $error = "Failed to update profile.";
        }
    }
}

// Fetch current details
$stmt = $pdo->prepare("SELECT * FROM Student WHERE student_id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 24px; margin: 0; color: var(--primary);">My Profile</h2>
    <p style="color: var(--text-muted); margin-top: 4px;">View and update your personal details.</p>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error" style="margin-bottom: 20px;"><?= $error ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1.5fr; gap: 24px;">
    
    <!-- Profile Card -->
    <div class="card" style="border-left: 4px solid var(--secondary); text-align: center; padding-top: 32px;">
        <div style="width: 80px; height: 80px; background: var(--primary); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: 800; margin: 0 auto 16px;">
            <?= strtoupper(substr($student['name'], 0, 1)) ?>
        </div>
        <h3 style="font-size: 20px; font-weight: 800; margin-bottom: 4px; color: var(--primary);"><?= htmlspecialchars($student['name']) ?></h3>
        <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 24px;">Student ID: <?= htmlspecialchars($student['student_id']) ?></p>
        
        <div style="background: var(--bg); padding: 16px; text-align: left; border-top: 1px solid var(--border); margin-top: 24px;">
            <div style="font-size: 13px; color: var(--text-muted); margin-bottom: 4px;">Email Address</div>
            <div style="font-weight: 600; font-size: 14px;"><?= htmlspecialchars($student['email']) ?></div>
        </div>
    </div>

    <!-- Edit Form -->
    <div class="card">
        <div class="card-header">
            <h3>Edit Details</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($student['name']) ?>" required>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($student['phone']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Year</label>
                        <select name="year" class="form-control">
                            <option value="1" <?= $student['year'] == 1 ? 'selected' : '' ?>>1st Year</option>
                            <option value="2" <?= $student['year'] == 2 ? 'selected' : '' ?>>2nd Year</option>
                            <option value="3" <?= $student['year'] == 3 ? 'selected' : '' ?>>3rd Year</option>
                            <option value="4" <?= $student['year'] == 4 ? 'selected' : '' ?>>4th Year</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Course</label>
                    <input type="text" name="course" class="form-control" value="<?= htmlspecialchars($student['course']) ?>" required>
                </div>

                <div style="margin-top: 32px; text-align: right;">
                    <button type="submit" class="btn btn-primary" style="padding: 12px 32px;">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>