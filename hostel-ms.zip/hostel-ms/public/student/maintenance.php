<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];
$msg = '';

// Handle Add Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $issue_type = $_POST['issue_type'];
    $description = trim($_POST['description']);
    $priority = $_POST['priority'];

    $stmt = $pdo->prepare("INSERT INTO Maintenance_Request (student_id, issue_type, description, priority, status) VALUES (?, ?, ?, ?, 'Pending')");
    if ($stmt->execute([$student_id, $issue_type, $description, $priority])) {
        $msg = "Maintenance request submitted successfully.";
    }
}

// Fetch my requests
$stmt = $pdo->prepare("SELECT * FROM Maintenance_Request WHERE student_id = ? ORDER BY request_id DESC");
$stmt->execute([$student_id]);
$requests = $stmt->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <div>
        <h2 style="font-size: 24px; margin: 0;">Maintenance Requests</h2>
        <p style="color: var(--text-muted); margin-top: 4px;">Report an issue with your room.</p>
    </div>
    <button class="btn btn-primary" onclick="openModal()">+ New Request</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Issue</th>
                    <th>Priority</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($requests) > 0): ?>
                    <?php foreach ($requests as $r): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($r['request_date'])) ?></td>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($r['issue_type']) ?></div>
                            <div style="font-size: 13px; color: var(--text-muted); margin-top: 4px;"><?= htmlspecialchars($r['description']) ?></div>
                        </td>
                        <td>
                            <?php 
                                $pClass = 'badge-info';
                                if ($r['priority'] == 'High') $pClass = 'badge-danger';
                                if ($r['priority'] == 'Medium') $pClass = 'badge-warning';
                            ?>
                            <span class="badge <?= $pClass ?>"><?= $r['priority'] ?></span>
                        </td>
                        <td>
                            <?php 
                                $sClass = 'badge-warning';
                                if ($r['status'] == 'Resolved') $sClass = 'badge-success';
                                if ($r['status'] == 'In Progress') $sClass = 'badge-info';
                            ?>
                            <span class="badge <?= $sClass ?>"><?= $r['status'] ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4" style="text-align: center; padding: 30px; color: var(--text-muted);">You haven't raised any maintenance requests.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="reqModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>New Maintenance Request</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div class="form-group">
                <label>Issue Type</label>
                <select name="issue_type" class="form-control">
                    <option value="Electrical">Electrical (Fan, Light, Switch)</option>
                    <option value="Plumbing">Plumbing (Tap, Toilet, Leak)</option>
                    <option value="Carpentry">Carpentry (Door, Window, Bed)</option>
                    <option value="Internet">Internet / Wi-Fi</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Describe the issue..." required></textarea>
            </div>

            <div class="form-group">
                <label>Priority</label>
                <select name="priority" class="form-control">
                    <option value="Low">Low</option>
                    <option value="Medium" selected>Medium</option>
                    <option value="High">High</option>
                </select>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit Request</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('reqModal');
    function openModal() { modal.classList.add('active'); }
    function closeModal() { modal.classList.remove('active'); }
</script>

<?php require '../../includes/footer.php'; ?>