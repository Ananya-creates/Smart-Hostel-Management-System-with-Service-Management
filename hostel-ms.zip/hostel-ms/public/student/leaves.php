<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $from = $_POST['from_date'];
    $to = $_POST['to_date'];
    $reason = trim($_POST['reason']);

    $stmt = $pdo->prepare("INSERT INTO Leave_Application (student_id, from_date, to_date, reason, status) VALUES (?, ?, ?, ?, 'Pending')");
    if ($stmt->execute([$student_id, $from, $to, $reason])) {
        $msg = "Leave application submitted.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM Leave_Application WHERE student_id = ? ORDER BY leave_id DESC");
$stmt->execute([$student_id]);
$leaves = $stmt->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <div>
        <h2 style="font-size: 24px; margin: 0;">Leave Applications</h2>
        <p style="color: var(--text-muted); margin-top: 4px;">Apply for leave from the hostel.</p>
    </div>
    <button class="btn btn-primary" onclick="openModal()">+ Apply for Leave</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Applied On</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($leaves) > 0): ?>
                    <?php foreach ($leaves as $l): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($l['applied_on'])) ?></td>
                        <td><b><?= date('d M Y', strtotime($l['from_date'])) ?></b></td>
                        <td><b><?= date('d M Y', strtotime($l['to_date'])) ?></b></td>
                        <td><?= htmlspecialchars($l['reason']) ?></td>
                        <td>
                            <?php 
                                $sClass = 'badge-warning';
                                if ($l['status'] == 'Approved') $sClass = 'badge-success';
                                if ($l['status'] == 'Rejected') $sClass = 'badge-danger';
                            ?>
                            <span class="badge <?= $sClass ?>"><?= $l['status'] ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">No leave applications found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal-overlay" id="leaveModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Apply for Leave</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div class="form-group">
                    <label>From Date</label>
                    <input type="date" name="from_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>To Date</label>
                    <input type="date" name="to_date" class="form-control" required>
                </div>
            </div>
            <div class="form-group">
                <label>Reason</label>
                <textarea name="reason" class="form-control" rows="3" required></textarea>
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit Application</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('leaveModal');
    function openModal() { modal.classList.add('active'); }
    function closeModal() { modal.classList.remove('active'); }
</script>

<?php require '../../includes/footer.php'; ?>