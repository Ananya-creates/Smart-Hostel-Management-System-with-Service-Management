<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];
$msg = '';

// Handle Add Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clothes_count = (int)$_POST['clothes_count'];

    $stmt = $pdo->prepare("INSERT INTO Laundry_Request (student_id, clothes_count, request_date, status) VALUES (?, ?, CURDATE(), 'Pending')");
    if ($stmt->execute([$student_id, $clothes_count])) {
        $msg = "Laundry request submitted successfully.";
    }
}

// Fetch my requests
$stmt = $pdo->prepare("SELECT * FROM Laundry_Request WHERE student_id = ? ORDER BY laundry_id DESC");
$stmt->execute([$student_id]);
$requests = $stmt->fetchAll();
?>

<style>
    .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: #fff; width: 100%; max-width: 400px; border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-lg); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-muted); }
</style>

<div class="toolbar">
    <div>
        <h2 style="font-size: 24px; margin: 0;">Laundry</h2>
        <p style="color: var(--text-muted); margin-top: 4px;">Submit your clothes for washing.</p>
    </div>
    <button class="btn btn-primary" onclick="openModal()">+ New Request</button>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom: 20px;"><?= $msg ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Request Date</th>
                    <th>Clothes Count</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($requests) > 0): ?>
                    <?php foreach ($requests as $r): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($r['request_date'])) ?></td>
                        <td><b><?= $r['clothes_count'] ?> items</b></td>
                        <td>
                            <?php 
                                $sClass = 'badge-warning';
                                if ($r['status'] == 'Ready') $sClass = 'badge-success';
                                if ($r['status'] == 'In Progress') $sClass = 'badge-info';
                            ?>
                            <span class="badge <?= $sClass ?>"><?= $r['status'] ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" style="text-align: center; padding: 30px; color: var(--text-muted);">No laundry requests found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal-overlay" id="laundryModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>New Laundry Request</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div class="form-group">
                <label>Number of Clothes</label>
                <input type="number" name="clothes_count" class="form-control" min="1" max="20" placeholder="e.g. 5" required>
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
                <button type="button" class="btn" style="background: var(--bg);" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('laundryModal');
    function openModal() { modal.classList.add('active'); }
    function closeModal() { modal.classList.remove('active'); }
</script>

<?php require '../../includes/footer.php'; ?>