<?php
require '../../config/db.php';
require '../../includes/student_header.php';

$student_id = $_SESSION['user_id'];

// Fetch my fee records
$stmt = $pdo->prepare("SELECT * FROM Fee WHERE student_id = ? ORDER BY fee_id DESC");
$stmt->execute([$student_id]);
$fees = $stmt->fetchAll();

// Calculate totals
$totalPaid = 0;
$totalPending = 0;
foreach ($fees as $f) {
    if ($f['payment_status'] == 'Paid') $totalPaid += $f['amount'];
    if ($f['payment_status'] == 'Pending' || $f['payment_status'] == 'Partial') $totalPending += $f['amount'];
}
?>

<div style="margin-bottom: 24px;">
    <h2 style="font-size: 24px; margin: 0;">My Fees</h2>
    <p style="color: var(--text-muted); margin-top: 4px;">View your fee breakdown and payment history.</p>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
    <div class="card" style="margin: 0; border-left: 4px solid var(--success);">
        <div class="card-body">
            <div style="font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Total Paid</div>
            <div style="font-size: 28px; font-weight: 800; margin-top: 8px; color: var(--success);">₹<?= number_format($totalPaid) ?></div>
        </div>
    </div>

    <div class="card" style="margin: 0; border-left: 4px solid var(--danger);">
        <div class="card-body">
            <div style="font-size: 13px; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Total Pending</div>
            <div style="font-size: 28px; font-weight: 800; margin-top: 8px; color: var(--danger);">₹<?= number_format($totalPending) ?></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Payment History</h3>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Receipt ID</th>
                    <th>Amount</th>
                    <th>Due Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($fees) > 0): ?>
                    <?php foreach ($fees as $f): ?>
                    <tr>
                        <td><b>#<?= $f['fee_id'] ?></b></td>
                        <td><b>₹<?= number_format($f['amount']) ?></b></td>
                        <td><?= date('d M Y', strtotime($f['due_date'])) ?></td>
                        <td>
                            <?php 
                                $badgeClass = 'badge-warning';
                                if ($f['payment_status'] == 'Paid') $badgeClass = 'badge-success';
                                if ($f['payment_status'] == 'Partial') $badgeClass = 'badge-info';
                            ?>
                            <span class="badge <?= $badgeClass ?>"><?= $f['payment_status'] ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4" style="text-align: center; padding: 30px; color: var(--text-muted);">No fee records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../../includes/footer.php'; ?>