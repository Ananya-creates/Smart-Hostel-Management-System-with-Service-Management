<?php
require 'config/db.php';

echo "<h1>Connection Successful! 🎉</h1>";

// Let's count the students to prove it works
$stmt = $pdo->query("SELECT COUNT(*) FROM Student");
$count = $stmt->fetchColumn();

echo "<p>There are currently <b>$count</b> students in the database.</p>";
?>