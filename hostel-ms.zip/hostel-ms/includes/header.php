<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: /hostel-ms/public/login.php");
    exit;
}
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel MS — Admin</title>
    <link rel="stylesheet" href="/hostel-ms/assets/css/style.css">
    <style>
        /* Layout specific to dashboard */
        .layout { display: flex; min-height: 100vh; background: var(--bg); }
        .sidebar { width: 260px; background: #fff; border-right: 1px solid var(--border); display: flex; flex-direction: column; }
        .sidebar-brand { padding: 24px; font-size: 20px; font-weight: 800; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; color: var(--primary); }
        .sidebar-brand span { background: var(--primary); color: #fff; padding: 4px 10px; border-radius: 8px; font-size: 14px; }
        .nav-menu { padding: 20px 12px; flex: 1; overflow-y: auto; }
        .nav-section { font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 700; margin: 20px 12px 8px; letter-spacing: 0.5px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 8px; color: var(--text); font-weight: 500; font-size: 14px; margin-bottom: 4px; transition: all 0.2s; }
        .nav-item:hover { background: var(--tertiary); color: var(--primary); }
        
        /* VIBRANT ORANGE ACTIVE STATE */
        .nav-item.active { background: var(--secondary); color: #fff; font-weight: 600; }
        
        .main-content { flex: 1; display: flex; flex-direction: column; background: var(--bg); }
        .topbar { height: 70px; background: #fff; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 32px; }
        .topbar-title { font-size: 18px; font-weight: 700; color: var(--primary); }
        .user-info { display: flex; align-items: center; gap: 12px; font-weight: 600; font-size: 14px; }
        
        /* DEEP ORANGE AVATAR */
        .avatar { width: 36px; height: 36px; background: var(--primary); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; }
        
        .page-body { padding: 32px; }
    </style>
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-brand">
            <span>H</span> Hostel MS
        </div>
        <div class="nav-menu">
            <div class="nav-section">Overview</div>
            <a href="/hostel-ms/public/admin/dashboard.php" class="nav-item <?= $current_page == 'dashboard.php' ? 'active' : '' ?>">▦ Dashboard</a>
            
            <div class="nav-section">Core Management</div>
            <a href="/hostel-ms/public/admin/students.php" class="nav-item <?= $current_page == 'students.php' ? 'active' : '' ?>">☲ Students</a>
            <a href="/hostel-ms/public/admin/rooms.php" class="nav-item <?= $current_page == 'rooms.php' ? 'active' : '' ?>">▣ Rooms</a>
            <a href="/hostel-ms/public/admin/allocations.php" class="nav-item <?= $current_page == 'allocations.php' ? 'active' : '' ?>">⚑ Allocations</a>
            
            <div class="nav-section">Services & Requests</div>
            <a href="/hostel-ms/public/admin/mess-menu.php" class="nav-item <?= $current_page == 'mess-menu.php' ? 'active' : '' ?>">☕ Mess Menu</a>
            <a href="/hostel-ms/public/admin/maintenance.php" class="nav-item <?= $current_page == 'maintenance.php' ? 'active' : '' ?>">⚠ Maintenance</a>
            <a href="/hostel-ms/public/admin/leaves.php" class="nav-item <?= $current_page == 'leaves.php' ? 'active' : '' ?>">✈ Leaves</a>
            <a href="/hostel-ms/public/admin/laundry.php" class="nav-item <?= $current_page == 'laundry.php' ? 'active' : '' ?>">⚙ Laundry</a>
            
            <div class="nav-section">Finance & Info</div>
            <a href="/hostel-ms/public/admin/fees.php" class="nav-item <?= $current_page == 'fees.php' ? 'active' : '' ?>">₹ Fees</a>
            <a href="/hostel-ms/public/admin/notices.php" class="nav-item <?= $current_page == 'notices.php' ? 'active' : '' ?>">✉ Notices</a>
            <a href="/hostel-ms/public/admin/visitors.php" class="nav-item <?= $current_page == 'visitors.php' ? 'active' : '' ?>">☺ Visitors</a>
        </div>
        <div style="padding: 20px; border-top: 1px solid var(--border);">
            <a href="/hostel-ms/public/logout.php" class="nav-item" style="color: var(--primary);">⏻ Logout</a>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="topbar-title">Admin Portal</div>
            <div class="user-info">
                <span><?= htmlspecialchars($_SESSION['name']) ?></span>
                <div class="avatar"><?= strtoupper(substr($_SESSION['name'], 0, 1)) ?></div>
            </div>
        </header>
        <div class="page-body">