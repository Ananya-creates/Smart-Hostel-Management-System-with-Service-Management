<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: /hostel-ms/public/login.php");
    exit;
}
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hostel MS — Student</title>
    <link rel="stylesheet" href="/hostel-ms/assets/css/style.css">
    <style>
        .layout { display: flex; min-height: 100vh; background: var(--bg); }
        .sidebar { width: 260px; background: #fff; border-right: 1px solid var(--border); display: flex; flex-direction: column; }
        .sidebar-brand { padding: 24px; font-size: 20px; font-weight: 800; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; color: var(--primary); }
        .sidebar-brand span { background: var(--primary); color: #fff; padding: 4px 10px; border-radius: 8px; font-size: 14px; }
        .nav-menu { padding: 20px 12px; flex: 1; overflow-y: auto; }
        .nav-section { font-size: 11px; text-transform: uppercase; color: var(--text-muted); font-weight: 700; margin: 20px 12px 8px; letter-spacing: 0.5px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 8px; color: var(--text); font-weight: 500; font-size: 14px; margin-bottom: 4px; transition: all 0.2s; }
        .nav-item:hover { background: var(--tertiary); color: var(--primary); }
        
        /* VIBRANT ORANGE ACTIVE STATE */
        .nav-item.active { background: var(--secondary); color: #fff; font-weight: 600; }
        
        .main-content { flex: 1; display: flex; flex-direction: column; background: var(--bg); }
        .topbar { height: 70px; background: #fff; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 32px; }
        .user-info { display: flex; align-items: center; gap: 12px; font-weight: 600; font-size: 14px; }
        
        /* DEEP ORANGE AVATAR */
        .avatar { width: 36px; height: 36px; background: var(--primary); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; }
        
        .page-body { padding: 32px; }
    </style>
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-brand">
            <span>H</span> My Hostel
        </div>
        <div class="nav-menu">
            <div class="nav-section">Overview</div>
            <a href="/hostel-ms/public/student/dashboard.php" class="nav-item <?= $current_page == 'dashboard.php' ? 'active' : '' ?>">▦ Dashboard</a>
            <a href="/hostel-ms/public/student/profile.php" class="nav-item <?= $current_page == 'profile.php' ? 'active' : '' ?>">☺ My Profile</a>
            
            <div class="nav-section">My Hostel</div>
            <a href="/hostel-ms/public/student/my-room.php" class="nav-item <?= $current_page == 'my-room.php' ? 'active' : '' ?>">▣ My Room</a>
            <a href="/hostel-ms/public/student/mess-menu.php" class="nav-item <?= $current_page == 'mess-menu.php' ? 'active' : '' ?>">☕ Mess Menu</a>
            <a href="/hostel-ms/public/student/my-visitors.php" class="nav-item <?= $current_page == 'my-visitors.php' ? 'active' : '' ?>">☺ My Visitors</a>
            
            <div class="nav-section">Requests</div>
            <a href="/hostel-ms/public/student/maintenance.php" class="nav-item <?= $current_page == 'maintenance.php' ? 'active' : '' ?>">⚠ Maintenance</a>
            <a href="/hostel-ms/public/student/laundry.php" class="nav-item <?= $current_page == 'laundry.php' ? 'active' : '' ?>">⚙ Laundry</a>
            <a href="/hostel-ms/public/student/leaves.php" class="nav-item <?= $current_page == 'leaves.php' ? 'active' : '' ?>">✈ Leaves</a>
            
            <div class="nav-section">Finance & Info</div>
            <a href="/hostel-ms/public/student/fees.php" class="nav-item <?= $current_page == 'fees.php' ? 'active' : '' ?>">₹ My Fees</a>
            <a href="/hostel-ms/public/student/notices.php" class="nav-item <?= $current_page == 'notices.php' ? 'active' : '' ?>">✉ Notices</a>
        </div>
        <div style="padding: 20px; border-top: 1px solid var(--border);">
            <a href="/hostel-ms/public/logout.php" class="nav-item" style="color: var(--primary);">⏻ Logout</a>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div style="font-size: 18px; font-weight: 700; color: var(--primary);">Student Portal</div>
            <div class="user-info">
                <span><?= htmlspecialchars($_SESSION['name']) ?></span>
                <div class="avatar"><?= strtoupper(substr($_SESSION['name'], 0, 1)) ?></div>
            </div>
        </header>
        <div class="page-body">